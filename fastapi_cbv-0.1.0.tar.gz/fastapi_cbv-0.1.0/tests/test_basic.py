"""
Basic tests for FastAPI CBV
"""

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from tortoise.contrib.fastapi import register_tortoise
from tortoise.models import Model
from tortoise import fields

from fastapi_cbv import (
    APIView, 
    ListCreateAPIView, 
    RetrieveUpdateDestroyAPIView,
    ModelViewSet,
    cbv,
    CBVRouter,
    create_tortoise_serializer,
    viewset_routes
)


# Test models
class TestUser(Model):
    id = fields.IntField(pk=True)
    name = fields.CharField(max_length=100)
    email = fields.CharField(max_length=100, unique=True)

    class Meta:
        table = "test_users"


# Test fixtures
@pytest.fixture
def app():
    app = FastAPI()
    register_tortoise(
        app,
        db_url="sqlite://:memory:",
        modules={"models": [__name__]},
        generate_schemas=True,
        add_exception_handlers=True,
    )
    return app


@pytest.fixture
def client(app):
    return TestClient(app)


@pytest.fixture
def router():
    return CBVRouter()


# Test basic APIView
def test_basic_api_view(app, client, router):
    @cbv(router)
    class HelloView(APIView):
        async def get(self):
            return {"message": "Hello World"}
    
    HelloView.add_api_route("/hello")
    app.include_router(router)
    
    response = client.get("/hello")
    assert response.status_code == 200
    assert response.json() == {"message": "Hello World"}


# Test model views
def test_model_views(app, client, router):
    UserSerializer = create_tortoise_serializer(TestUser)
    
    class UserListView(ListCreateAPIView):
        queryset = TestUser.all()
        serializer_class = UserSerializer
    
    class UserDetailView(RetrieveUpdateDestroyAPIView):
        queryset = TestUser.all()
        serializer_class = UserSerializer
    
    router.add_cbv_route("/users", UserListView)
    router.add_cbv_route("/users/{id}", UserDetailView)
    app.include_router(router)
    
    # Test list endpoint
    response = client.get("/users")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


# Test ViewSet
def test_viewset(app, client, router):
    UserSerializer = create_tortoise_serializer(TestUser)
    
    class UserViewSet(ModelViewSet):
        queryset = TestUser.all()
        serializer_class = UserSerializer
    
    viewset_routes(router, UserViewSet, prefix="/users")
    app.include_router(router)
    
    # Test list endpoint
    response = client.get("/users/")
    assert response.status_code == 200


if __name__ == "__main__":
    pytest.main([__file__])