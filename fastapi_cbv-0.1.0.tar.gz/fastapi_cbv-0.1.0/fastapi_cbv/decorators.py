"""
Decorators for FastAPI CBV

This module provides decorators to make it easy to use class-based views with FastAPI.
"""

from typing import Type, Dict, List, Optional, Any, Callable, Union
from functools import wraps
import inspect

from fastapi import APIRouter, Depends, HTTPException
from fastapi.routing import APIRoute

from .views.base import APIView
from .views.viewsets import ViewSetMixin


def cbv(router: APIRouter):
    """
    Class-based view decorator for FastAPI.
    
    This decorator allows you to use class-based views with FastAPI routers.
    It automatically converts the class methods to route handlers.
    
    Usage:
        router = APIRouter()
        
        @cbv(router)
        class UserView(APIView):
            async def get(self):
                return {"message": "Hello World"}
        
        # Then add routes
        UserView.add_api_route("/users", methods=["GET"])
    
    Args:
        router: The FastAPI router to register routes with
    
    Returns:
        A decorator function that enhances the view class
    """
    def decorator(cls: Type[APIView]) -> Type[APIView]:
        # Store the router on the class
        cls._cbv_router = router
        
        # Add route registration methods to the class
        def add_api_route(
            path: str,
            *,
            methods: Optional[List[str]] = None,
            name: Optional[str] = None,
            dependencies: Optional[List[Depends]] = None,
            **kwargs
        ):
            """
            Add an API route for this view class.
            """
            if methods is None:
                # Auto-detect available methods
                methods = []
                for method in cls.http_method_names:
                    if hasattr(cls, method) and callable(getattr(cls, method)):
                        methods.append(method.upper())
            
            # Create the endpoint function
            endpoint = cls.as_view()
            
            # Add dependencies if provided
            if dependencies:
                original_endpoint = endpoint
                
                async def endpoint_with_deps(*args, **kwargs):
                    # Dependencies are handled by FastAPI automatically
                    return await original_endpoint(*args, **kwargs)
                
                endpoint = endpoint_with_deps
            
            # Register the route
            router.add_api_route(
                path=path,
                endpoint=endpoint,
                methods=methods,
                name=name or cls.__name__.lower(),
                dependencies=dependencies,
                **kwargs
            )
        
        def add_route_with_action(
            path: str,
            action: str,
            method: str = "GET",
            *,
            name: Optional[str] = None,
            dependencies: Optional[List[Depends]] = None,
            **kwargs
        ):
            """
            Add a route for a specific action method.
            """
            if not hasattr(cls, action):
                raise ValueError(f"Action '{action}' not found on {cls.__name__}")
            
            # Create a wrapper that calls the specific action
            async def action_endpoint(request, **route_kwargs):
                instance = cls(request=request)
                handler = getattr(instance, action)
                
                # Perform initial setup
                await instance.initial(request)
                
                # Call the action
                if inspect.iscoroutinefunction(handler):
                    response = await handler(**route_kwargs)
                else:
                    response = handler(**route_kwargs)
                
                # Handle the response
                return await instance.finalize_response(response)
            
            router.add_api_route(
                path=path,
                endpoint=action_endpoint,
                methods=[method.upper()],
                name=name or f"{cls.__name__.lower()}_{action}",
                dependencies=dependencies,
                **kwargs
            )
        
        # Add methods to the class
        cls.add_api_route = add_api_route
        cls.add_route_with_action = add_route_with_action
        
        return cls
    
    return decorator


def viewset_routes(
    router: APIRouter,
    viewset_class: Type[ViewSetMixin],
    prefix: str = "",
    *,
    basename: Optional[str] = None,
    dependencies: Optional[List[Depends]] = None
):
    """
    Register all standard routes for a ViewSet.
    
    This function automatically creates the standard REST API routes:
    - GET /items/ -> list
    - POST /items/ -> create  
    - GET /items/{id}/ -> retrieve
    - PUT /items/{id}/ -> update
    - PATCH /items/{id}/ -> partial_update
    - DELETE /items/{id}/ -> destroy
    
    Args:
        router: The FastAPI router
        viewset_class: The ViewSet class
        prefix: URL prefix for all routes
        basename: Base name for route names (defaults to viewset class name)
        dependencies: Common dependencies for all routes
    
    Example:
        router = APIRouter()
        viewset_routes(router, UserViewSet, prefix="/users", basename="user")
    """
    if basename is None:
        basename = viewset_class.__name__.lower().replace('viewset', '')
    
    # Define the standard action mappings
    list_create_actions = {}
    detail_actions = {}
    
    # Check which actions are available
    if hasattr(viewset_class, 'list'):
        list_create_actions['get'] = 'list'
    if hasattr(viewset_class, 'create'):
        list_create_actions['post'] = 'create'
    
    if hasattr(viewset_class, 'retrieve'):
        detail_actions['get'] = 'retrieve'
    if hasattr(viewset_class, 'update'):
        detail_actions['put'] = 'update'
    if hasattr(viewset_class, 'partial_update'):
        detail_actions['patch'] = 'partial_update'
    if hasattr(viewset_class, 'destroy'):
        detail_actions['delete'] = 'destroy'
    
    # Register list/create route
    if list_create_actions:
        router.add_api_route(
            path=f"{prefix}/",
            endpoint=viewset_class.as_view(actions=list_create_actions),
            methods=list(method.upper() for method in list_create_actions.keys()),
            name=f"{basename}-list",
            dependencies=dependencies
        )
    
    # Register detail routes
    if detail_actions:
        router.add_api_route(
            path=f"{prefix}/{{id}}/",
            endpoint=viewset_class.as_view(actions=detail_actions),
            methods=list(method.upper() for method in detail_actions.keys()),
            name=f"{basename}-detail",
            dependencies=dependencies
        )


def api_route(
    path: str,
    *,
    methods: Optional[List[str]] = None,
    name: Optional[str] = None,
    dependencies: Optional[List[Depends]] = None,
    **kwargs
):
    """
    Method decorator for adding routes to individual view methods.
    
    Usage:
        @cbv(router)
        class UserView(APIView):
            @api_route("/users/{user_id}/profile", methods=["GET"])
            async def get_user_profile(self, user_id: int):
                return {"user_id": user_id}
    """
    def decorator(method: Callable) -> Callable:
        # Store route information on the method
        method._route_info = {
            'path': path,
            'methods': methods or ['GET'],
            'name': name,
            'dependencies': dependencies,
            **kwargs
        }
        return method
    
    return decorator


class RouteRegistry:
    """
    Registry for automatically collecting and registering routes from decorated methods.
    """
    
    @classmethod
    def register_decorated_routes(cls, view_class: Type[APIView], router: APIRouter):
        """
        Register all routes that were decorated with @api_route.
        """
        for attr_name in dir(view_class):
            attr = getattr(view_class, attr_name)
            if hasattr(attr, '_route_info'):
                route_info = attr._route_info
                
                # Create endpoint that calls the specific method
                def create_endpoint(method_name=attr_name):
                    async def endpoint(request, **kwargs):
                        instance = view_class(request=request)
                        method = getattr(instance, method_name)
                        
                        await instance.initial(request)
                        
                        if inspect.iscoroutinefunction(method):
                            response = await method(**kwargs)
                        else:
                            response = method(**kwargs)
                        
                        return await instance.finalize_response(response)
                    
                    return endpoint
                
                endpoint_func = create_endpoint()
                
                router.add_api_route(
                    path=route_info['path'],
                    endpoint=endpoint_func,
                    methods=route_info['methods'],
                    name=route_info['name'] or f"{view_class.__name__.lower()}_{attr_name}",
                    dependencies=route_info['dependencies']
                )