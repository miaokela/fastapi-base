"""
FastAPI CBV - Class-Based Views for FastAPI
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A FastAPI extension that provides Django REST Framework style class-based views
with full async support and Tortoise ORM integration.

:copyright: (c) 2024
:license: MIT
"""

__version__ = "0.1.0"
__author__ = "FastAPI CBV Team"

from .views.base import APIView, GenericAPIView
from .views.mixins import (
    CreateModelMixin,
    ListModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin,
)
from .views.generics import (
    CreateAPIView,
    ListAPIView,
    RetrieveAPIView,
    UpdateAPIView,
    DestroyAPIView,
    ListCreateAPIView,
    RetrieveUpdateAPIView,
    RetrieveDestroyAPIView,
    RetrieveUpdateDestroyAPIView,
)
from .views.viewsets import ModelViewSet, ReadOnlyModelViewSet
from .decorators import cbv, viewset_routes
from .routers import CBVRouter
from .tortoise_integration import (
    create_tortoise_serializer,
    TortoisePagination,
    TortoiseFilterBackend,
    TortoiseSearchBackend,
    TortoiseOrderingBackend,
)

__all__ = [
    # Base classes
    "APIView",
    "GenericAPIView",
    # Mixins
    "CreateModelMixin",
    "ListModelMixin", 
    "RetrieveModelMixin",
    "UpdateModelMixin",
    "DestroyModelMixin",
    # Generic views
    "CreateAPIView",
    "ListAPIView",
    "RetrieveAPIView", 
    "UpdateAPIView",
    "DestroyAPIView",
    "ListCreateAPIView",
    "RetrieveUpdateAPIView",
    "RetrieveDestroyAPIView",
    "RetrieveUpdateDestroyAPIView",
    # ViewSets
    "ModelViewSet",
    "ReadOnlyModelViewSet",
    # Decorators and utilities
    "cbv",
    "viewset_routes",
    "CBVRouter",
    # Tortoise ORM integration
    "create_tortoise_serializer",
    "TortoisePagination",
    "TortoiseFilterBackend",
    "TortoiseSearchBackend",
    "TortoiseOrderingBackend",
]