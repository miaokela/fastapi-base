"""
Base view classes for FastAPI CBV
"""

import inspect
from typing import Any, Dict, List, Optional, Type, Union, Callable, Set
from abc import ABC, abstractmethod

from fastapi import Request, Response, HTTPException, status, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from tortoise.models import Model
from tortoise.queryset import QuerySet


class APIView:
    """
    Base class for all API views.
    
    Provides the basic structure for handling HTTP requests in a class-based manner,
    similar to Django REST Framework's APIView.
    """
    
    # Allowed HTTP methods - override in subclasses as needed
    http_method_names = ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']
    
    # Authentication and permission classes
    authentication_classes: List[Type] = []
    permission_classes: List[Type] = []
    
    # Content negotiation
    content_negotiation_class = None
    parser_classes: List[Type] = []
    renderer_classes: List[Type] = []
    
    def __init__(self, request: Request = None, **kwargs):
        """
        Initialize the view with request context.
        """
        self.request = request
        self.format_kwarg = None
        self.args = []
        self.kwargs = kwargs
    
    @classmethod
    def as_view(cls, **initkwargs):
        """
        Return a view function that can be used by FastAPI routing.
        """
        for key in initkwargs:
            if key in cls.http_method_names:
                raise TypeError(
                    f"The method name {key} is not accepted as a keyword argument "
                    f"to {cls.__name__}()."
                )
            if not hasattr(cls, key):
                raise TypeError(
                    f"{cls.__name__}() received an invalid keyword {key}. "
                    f"as_view only accepts arguments that are already "
                    f"attributes of the class."
                )
        
        async def view(request: Request):
            self = cls(request=request, **initkwargs)
            # Extract path parameters from request and store in kwargs
            if hasattr(request, 'path_params'):
                self.kwargs.update(dict(request.path_params))
            return await self.dispatch(request)
        
        view.view_class = cls
        view.view_initkwargs = initkwargs
        
        # Copy some attributes for introspection
        view.__name__ = cls.__name__
        view.__qualname__ = cls.__qualname__
        view.__module__ = cls.__module__
        view.__doc__ = cls.__doc__
        
        return view
    
    async def dispatch(self, request: Request):
        """
        Dispatch the request to the appropriate handler method.
        """
        # Set up the request
        self.request = request
        self.args = []
        # Extract path parameters from the request
        self.kwargs = dict(request.path_params) if hasattr(request, 'path_params') else {}
        
        # Get the HTTP method
        method = request.method.lower()
        
        # Check if the method is allowed
        if method not in self.http_method_names:
            raise HTTPException(
                status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
                detail=f"Method '{method.upper()}' not allowed."
            )
        
        # Get the handler method
        handler = getattr(self, method, None)
        if handler is None:
            raise HTTPException(
                status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
                detail=f"Method '{method.upper()}' not allowed."
            )
        
        # Perform authentication and permission checks
        await self.initial(request)
        
        # Call the handler
        if inspect.iscoroutinefunction(handler):
            response = await handler(**self.kwargs)
        else:
            response = handler(**self.kwargs)
        
        # Handle the response
        return await self.finalize_response(response)
    
    async def initial(self, request: Request):
        """
        Runs anything that needs to occur prior to calling the method handler.
        """
        # Perform authentication
        await self.perform_authentication(request)
        
        # Check permissions
        await self.check_permissions(request)
        
        # Check throttles
        await self.check_throttles(request)
    
    async def perform_authentication(self, request: Request):
        """
        Perform authentication on the incoming request.
        """
        # TODO: Implement authentication
        pass
    
    async def check_permissions(self, request: Request):
        """
        Check if the request should be permitted.
        """
        # TODO: Implement permission checking
        pass
    
    async def check_throttles(self, request: Request):
        """
        Check if request should be throttled.
        """
        # TODO: Implement throttling
        pass
    
    async def finalize_response(self, response: Any):
        """
        Given the response returned from the view, return an HTTP response.
        """
        from pydantic import BaseModel
        
        if isinstance(response, Response):
            return response
        
        # Convert Pydantic models to dict (for input validation)
        if isinstance(response, BaseModel):
            response = response.model_dump(mode='json')
        elif isinstance(response, list):
            # Check if list contains Pydantic models
            if len(response) > 0 and isinstance(response[0], BaseModel):
                response = [item.model_dump(mode='json') for item in response]
            # List of dicts is already fine
        
        # Convert to JSON response if needed
        if isinstance(response, (dict, list)):
            return JSONResponse(content=response)
        
        return response
    
    def get_serializer_context(self):
        """
        Extra context provided to the serializer class.
        """
        return {
            'request': self.request,
            'format': self.format_kwarg,
            'view': self
        }


class GenericAPIView(APIView):
    """
    Base class for all generic views.
    
    Provides common functionality for working with querysets and serializers.
    Similar to Django REST framework's GenericAPIView.
    """
    
    # Model configuration
    queryset: Optional[QuerySet] = None
    model: Optional[Type[Model]] = None
    
    # Serialization
    serializer_class: Optional[Type[BaseModel]] = None
    
    # Lookup configuration
    lookup_field = 'id'
    lookup_url_kwarg: Optional[str] = None
    
    # Filtering, searching, and ordering
    filter_backends: List[Type] = []
    search_fields: List[str] = []
    ordering_fields: List[str] = []
    ordering: Optional[Union[str, List[str]]] = None
    
    # Pagination
    pagination_class: Optional[Type] = None
    
    # DateTime formatting configuration
    # Set to None for ISO format (default), or provide a strftime format string
    # Examples: "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y %H:%M"
    # Default: 年-月-日 时:分:秒 格式
    datetime_format: Optional[str] = "%Y-%m-%d %H:%M:%S"
    date_format: Optional[str] = "%Y-%m-%d"
    
    def get_queryset(self) -> QuerySet:
        """
        Get the list of items for this view.
        """
        if self.queryset is not None:
            queryset = self.queryset
            if isinstance(queryset, QuerySet):
                # Ensure queryset is re-evaluated on each request
                queryset = queryset.all()
            return queryset
        
        if self.model is not None:
            return self.model.all()
        
        raise NotImplementedError(
            f"{self.__class__.__name__} must define either 'queryset' or 'model', "
            f"or override the get_queryset() method."
        )
    
    async def get_object(self) -> Model:
        """
        Return the object the view is displaying.
        """
        queryset = self.get_queryset()
        
        # Perform the lookup filtering
        lookup_url_kwarg = self.lookup_url_kwarg or self.lookup_field
        
        if lookup_url_kwarg not in self.kwargs:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Expected URL keyword argument '{lookup_url_kwarg}'."
            )
        
        filter_kwargs = {self.lookup_field: self.kwargs[lookup_url_kwarg]}
        
        try:
            obj = await queryset.get(**filter_kwargs)
        except Exception:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Not found."
            )
        
        # May raise a permission denied
        await self.check_object_permissions(obj)
        
        return obj
    
    async def check_object_permissions(self, obj: Model):
        """
        Check if the request should be permitted for a given object.
        """
        # TODO: Implement object-level permission checking
        pass
    
    def get_serializer_class(self) -> Type[BaseModel]:
        """
        Return the class to use for the serializer.
        """
        if self.serializer_class is not None:
            return self.serializer_class
        
        raise NotImplementedError(
            f"{self.__class__.__name__} must define 'serializer_class' "
            f"or override the get_serializer_class() method."
        )
    
    def get_serializer(self, instance=None, data=None, many=False, partial=False):
        """
        Return a serializer instance or serialized data.
        For Tortoise ORM integration, this handles data serialization differently.
        """
        serializer_class = self.get_serializer_class()
        
        if data is not None:
            # For creating/updating with input data - return Pydantic instance for validation
            if partial:
                # For partial updates, use model_validate with from_attributes=True
                # This allows partial validation without required fields
                try:
                    # Create instance with only the provided fields
                    # Pydantic v2: use model_validate with from_attributes and arbitrary_types_allowed
                    return serializer_class.model_validate(data, from_attributes=True)
                except Exception:
                    # Fallback: try to create with just the provided data
                    # This will work if the model has defaults for missing fields
                    return serializer_class(**data)
            else:
                # For full validation, use the standard constructor
                return serializer_class(**data)
        elif instance is not None:
            # For reading/serializing existing instances
            # Returns dict or list of dicts (already JSON-safe)
            if many:
                return [self._model_to_dict(item, serializer_class) for item in instance]
            else:
                return self._model_to_dict(instance, serializer_class)
        else:
            # Return the class itself
            return serializer_class
    
    def _model_to_dict(self, instance, serializer_class):
        """
        Convert a Tortoise model instance to a dict.
        Handles foreign key fields and datetime serialization properly.
        """
        from tortoise import fields as tortoise_fields
        from datetime import datetime, date
        
        data = {}
        model_class = type(instance)
        
        # Get all fields defined in the serializer
        if hasattr(serializer_class, 'model_fields'):
            serializer_fields = serializer_class.model_fields.keys()
        else:
            # Fallback to model fields
            serializer_fields = model_class._meta.fields_map.keys()
        
        for field_name in serializer_fields:
            if field_name in model_class._meta.fields_map:
                field_obj = model_class._meta.fields_map[field_name]
                
                # Handle foreign key fields - get the ID value
                if isinstance(field_obj, tortoise_fields.relational.ForeignKeyFieldInstance):
                    # Get the foreign key ID value
                    fk_id_attr = f"{field_name}_id"
                    if hasattr(instance, fk_id_attr):
                        data[field_name] = getattr(instance, fk_id_attr)
                    else:
                        data[field_name] = None
                else:
                    # Regular field
                    if hasattr(instance, field_name):
                        value = getattr(instance, field_name)
                        # Convert datetime/date to string for JSON compatibility
                        if isinstance(value, datetime):
                            # Use custom format if specified, otherwise ISO format
                            if self.datetime_format:
                                value = value.strftime(self.datetime_format)
                            else:
                                value = value.isoformat()
                        elif isinstance(value, date):
                            # Use custom format if specified, otherwise ISO format
                            if self.date_format:
                                value = value.strftime(self.date_format)
                            else:
                                value = value.isoformat()
                        data[field_name] = value
        
        # Return dict directly without going through Pydantic
        # This ensures datetime strings stay as strings
        return data
    
    def filter_queryset(self, queryset: QuerySet) -> QuerySet:
        """
        Given a queryset, filter it with whichever filter backends are in use.
        """
        for backend in list(self.filter_backends):
            queryset = backend().filter_queryset(self.request, queryset, self)
        return queryset
    
    async def paginate_queryset(self, queryset: QuerySet):
        """
        Return a single page of results, or None if pagination is disabled.
        """
        if self.pagination_class is None:
            return None
        
        paginator = self.pagination_class()
        if hasattr(paginator, 'paginate_queryset') and inspect.iscoroutinefunction(paginator.paginate_queryset):
            return await paginator.paginate_queryset(queryset, self.request, view=self)
        else:
            return paginator.paginate_queryset(queryset, self.request, view=self)
    
    def get_paginated_response(self, data):
        """
        Return a paginated style Response object for the given output data.
        """
        if self.pagination_class is None:
            return data
        
        paginator = self.pagination_class()
        return paginator.get_paginated_response(data)