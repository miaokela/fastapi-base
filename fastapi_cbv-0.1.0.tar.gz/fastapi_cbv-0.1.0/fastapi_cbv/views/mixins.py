"""
Mixin classes for FastAPI CBV

These mixins provide common behaviors for API views, similar to Django REST Framework.
Each mixin provides a specific set of actions that can be combined to create complete views.
"""

import inspect
from typing import Any, Dict, List, Optional, Union

from fastapi import HTTPException, status
from pydantic import BaseModel, ValidationError
from tortoise.models import Model
from tortoise.queryset import QuerySet


class CreateModelMixin:
    """
    Create a model instance.
    
    Provides a `create` action and a default `post` method.
    """
    
    async def create(self, **kwargs):
        """
        Create a new model instance.
        """
        # Get request data
        if hasattr(self.request, 'json'):
            try:
                if inspect.iscoroutinefunction(self.request.json):
                    data = await self.request.json()
                else:
                    data = self.request.json()
            except Exception:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid JSON data."
                )
        else:
            data = {}
        
        # Validate and create instance
        serializer = self.get_serializer(data=data)
        
        try:
            # Validate the data
            if hasattr(serializer, 'parse_obj'):
                validated_data = serializer.parse_obj(data)
            else:
                validated_data = serializer(**data)
        except ValidationError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=e.errors()
            )
        
        # Perform the creation
        instance = await self.perform_create(validated_data)
        
        # Return serialized data
        response_serializer = self.get_serializer(instance=instance)
        return self.get_success_response(response_serializer, status_code=status.HTTP_201_CREATED)
    
    async def perform_create(self, validated_data):
        """
        Create and return a new model instance, given the validated data.
        """
        # Convert Pydantic model to dict if needed
        if isinstance(validated_data, BaseModel):
            validated_data = validated_data.dict(exclude_unset=True)
        
        # Get the model class
        model_class = self.get_queryset().model
        
        # Convert foreign key fields (e.g., 'author' -> 'author_id')
        from tortoise import fields as tortoise_fields
        converted_data = {}
        for field_name, value in validated_data.items():
            if field_name in model_class._meta.fields_map:
                field_obj = model_class._meta.fields_map[field_name]
                # Check if it's a foreign key field
                if isinstance(field_obj, tortoise_fields.relational.ForeignKeyFieldInstance):
                    # Use the field name with _id suffix
                    converted_data[f"{field_name}_id"] = value
                else:
                    converted_data[field_name] = value
            else:
                converted_data[field_name] = value
        
        # Create the instance
        instance = await model_class.create(**converted_data)
        return instance
    
    def get_success_response(self, serializer, status_code=None):
        """
        Return the response after successful creation.
        """
        from pydantic import BaseModel
        
        # If serializer is already a dict (from get_serializer with instance), return it
        if isinstance(serializer, dict):
            return serializer
        elif isinstance(serializer, BaseModel):
            return serializer.model_dump(mode='json')
        elif hasattr(serializer, 'dict'):
            return serializer.dict()
        elif hasattr(serializer, 'data'):
            return serializer.data
        else:
            return serializer
    
    async def post(self, **kwargs):
        """
        Handle POST request for creating a new instance.
        """
        return await self.create(**kwargs)


class ListModelMixin:
    """
    List a queryset.
    
    Provides a `list` action and a default `get` method for listing.
    """
    
    async def list(self, **kwargs):
        """
        List all instances or a filtered subset.
        """
        queryset = self.get_queryset()
        
        # Apply filtering
        queryset = self.filter_queryset(queryset)
        
        # Apply pagination if configured
        page = None
        if self.pagination_class is not None:
            # Create pagination instance if it's a class
            if isinstance(self.pagination_class, type):
                paginator = self.pagination_class()
            else:
                paginator = self.pagination_class
            
            # Paginate the queryset
            instances = await paginator.paginate_queryset(queryset, self.request, self)
            page = paginator
        else:
            # No pagination - get all instances
            instances = await queryset
        
        # Serialize the instances
        serializer = self.get_serializer(instances, many=True)
        
        # Get serialized data
        if isinstance(serializer, list):
            # Already a list of dicts from _model_to_dict
            data = serializer
        elif hasattr(serializer, 'dict'):
            data = serializer.dict()
        elif hasattr(serializer, 'data'):
            data = serializer.data
        else:
            data = [self._serialize_instance(instance) for instance in instances]
        
        # Return paginated response if pagination is enabled
        if page is not None:
            return page.get_paginated_response(data)
        
        return data
    
    def _serialize_instance(self, instance):
        """
        Serialize a single instance.
        """
        if hasattr(instance, 'dict'):
            return instance.dict()
        elif hasattr(instance, '__dict__'):
            return {k: v for k, v in instance.__dict__.items() if not k.startswith('_')}
        else:
            return str(instance)
    
    async def get(self, **kwargs):
        """
        Handle GET request for listing instances.
        """
        return await self.list(**kwargs)


class RetrieveModelMixin:
    """
    Retrieve a model instance.
    
    Provides a `retrieve` action and a default `get` method for retrieving a single instance.
    """
    
    async def retrieve(self, **kwargs):
        """
        Retrieve a single instance.
        """
        instance = await self.get_object()
        serializer = self.get_serializer(instance=instance)
        
        # Check if serializer is already a dict (from _model_to_dict)
        if isinstance(serializer, dict):
            return serializer
        elif hasattr(serializer, 'dict'):
            return serializer.dict()
        elif hasattr(serializer, 'data'):
            return serializer.data
        else:
            return self._serialize_instance(instance)
    
    def _serialize_instance(self, instance):
        """
        Serialize a single instance.
        """
        if hasattr(instance, 'dict'):
            return instance.dict()
        elif hasattr(instance, '__dict__'):
            return {k: v for k, v in instance.__dict__.items() if not k.startswith('_')}
        else:
            return str(instance)
    
    async def get(self, **kwargs):
        """
        Handle GET request for retrieving a single instance.
        """
        return await self.retrieve(**kwargs)


class UpdateModelMixin:
    """
    Update a model instance.
    
    Provides `update` and `partial_update` actions, and default `put` and `patch` methods.
    """
    
    async def update(self, partial=False, **kwargs):
        """
        Update an existing instance.
        """
        instance = await self.get_object()
        
        # Get request data
        if hasattr(self.request, 'json'):
            try:
                if inspect.iscoroutinefunction(self.request.json):
                    data = await self.request.json()
                else:
                    data = self.request.json()
            except Exception:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid JSON data."
                )
        else:
            data = {}
        
        # For partial updates, skip full Pydantic validation
        # Just validate individual field types as we update
        if partial:
            validated_data = data
        else:
            # Validate the data for full updates
            serializer = self.get_serializer(data=data, partial=partial)
            
            try:
                if hasattr(serializer, 'parse_obj'):
                    validated_data = serializer.parse_obj(data)
                elif isinstance(serializer, BaseModel):
                    # Already a Pydantic instance from get_serializer(data=data)
                    validated_data = serializer
                else:
                    validated_data = serializer(**data)
            except ValidationError as e:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=e.errors()
                )
        
        # Perform the update
        instance = await self.perform_update(instance, validated_data)
        
        # Return updated data
        response_serializer = self.get_serializer(instance=instance)
        return self.get_success_response(response_serializer)
    
    async def perform_update(self, instance, validated_data):
        """
        Update and return an existing model instance, given the validated data.
        """
        # Convert Pydantic model to dict if needed
        if isinstance(validated_data, BaseModel):
            validated_data = validated_data.dict(exclude_unset=True)
        
        # Convert foreign key fields (e.g., 'author' -> 'author_id')
        from tortoise import fields as tortoise_fields
        model_class = type(instance)
        
        # Update the instance
        for key, value in validated_data.items():
            if key in model_class._meta.fields_map:
                field_obj = model_class._meta.fields_map[key]
                # Check if it's a foreign key field
                if isinstance(field_obj, tortoise_fields.relational.ForeignKeyFieldInstance):
                    # Use the field name with _id suffix
                    setattr(instance, f"{key}_id", value)
                else:
                    setattr(instance, key, value)
            else:
                setattr(instance, key, value)
        
        await instance.save()
        return instance
    
    async def partial_update(self, **kwargs):
        """
        Partially update an existing instance.
        """
        return await self.update(partial=True, **kwargs)
    
    def get_success_response(self, serializer, status_code=None):
        """
        Return the response after successful update.
        """
        from pydantic import BaseModel
        
        # If serializer is already a dict (from get_serializer with instance), return it
        if isinstance(serializer, dict):
            return serializer
        elif isinstance(serializer, BaseModel):
            return serializer.model_dump(mode='json')
        elif hasattr(serializer, 'dict'):
            return serializer.dict()
        elif hasattr(serializer, 'data'):
            return serializer.data
        else:
            return serializer
    
    async def put(self, **kwargs):
        """
        Handle PUT request for full update.
        """
        return await self.update(**kwargs)
    
    async def patch(self, **kwargs):
        """
        Handle PATCH request for partial update.
        """
        return await self.partial_update(**kwargs)


class DestroyModelMixin:
    """
    Destroy a model instance.
    
    Provides a `destroy` action and a default `delete` method.
    """
    
    async def destroy(self, **kwargs):
        """
        Destroy an instance.
        """
        instance = await self.get_object()
        await self.perform_destroy(instance)
        return {"detail": "Successfully deleted."}
    
    async def perform_destroy(self, instance):
        """
        Delete the given instance.
        """
        await instance.delete()
    
    async def delete(self, **kwargs):
        """
        Handle DELETE request for destroying an instance.
        """
        return await self.destroy(**kwargs)