"""
Custom router for FastAPI CBV

This module provides an enhanced router that makes it easier to work with class-based views.
"""

from typing import Any, Callable, Dict, List, Optional, Type, Union
import inspect

from fastapi import APIRouter as FastAPIRouter, Depends
from fastapi.routing import APIRoute

from .views.base import APIView
from .views.viewsets import ViewSetMixin
from .decorators import viewset_routes


class CBVRouter(FastAPIRouter):
    """
    Enhanced FastAPI router with built-in support for class-based views.
    
    This router provides convenience methods for registering CBV routes.
    """
    
    def add_cbv_route(
        self,
        path: str,
        view_class: Type[APIView],
        *,
        methods: Optional[List[str]] = None,
        name: Optional[str] = None,
        dependencies: Optional[List[Depends]] = None,
        **kwargs
    ):
        """
        Add a route for a class-based view.
        
        Args:
            path: The URL path
            view_class: The view class
            methods: HTTP methods to handle
            name: Route name
            dependencies: Route dependencies
            **kwargs: Additional arguments passed to add_api_route
        """
        if methods is None:
            # Auto-detect methods from the view class
            methods = []
            for method in view_class.http_method_names:
                if hasattr(view_class, method) and callable(getattr(view_class, method)):
                    methods.append(method.upper())
        
        # Create the endpoint
        endpoint = view_class.as_view()
        
        # Register the route
        self.add_api_route(
            path=path,
            endpoint=endpoint,
            methods=methods,
            name=name or view_class.__name__.lower(),
            dependencies=dependencies,
            **kwargs
        )
    
    def add_viewset_routes(
        self,
        viewset_class: Type[ViewSetMixin],
        prefix: str = "",
        *,
        basename: Optional[str] = None,
        dependencies: Optional[List[Depends]] = None,
        **kwargs
    ):
        """
        Add standard REST routes for a ViewSet.
        
        Args:
            viewset_class: The ViewSet class
            prefix: URL prefix for routes
            basename: Base name for route names
            dependencies: Common dependencies
            **kwargs: Additional arguments
        """
        viewset_routes(
            router=self,
            viewset_class=viewset_class,
            prefix=prefix,
            basename=basename,
            dependencies=dependencies
        )
    
    def include_cbv(
        self,
        view_class: Type[APIView],
        *,
        prefix: str = "",
        tags: Optional[List[str]] = None,
        dependencies: Optional[List[Depends]] = None,
        **kwargs
    ):
        """
        Include all routes from a CBV class that uses the @api_route decorator.
        
        Args:
            view_class: The view class with decorated methods
            prefix: URL prefix
            tags: OpenAPI tags
            dependencies: Common dependencies
            **kwargs: Additional arguments
        """
        # Create a sub-router for this view
        sub_router = CBVRouter(prefix=prefix, tags=tags, dependencies=dependencies)
        
        # Register decorated routes
        self._register_decorated_routes(view_class, sub_router)
        
        # Include the sub-router
        self.include_router(sub_router, **kwargs)
    
    def _register_decorated_routes(self, view_class: Type[APIView], router: 'CBVRouter'):
        """
        Register routes from methods decorated with @api_route.
        """
        for attr_name in dir(view_class):
            attr = getattr(view_class, attr_name)
            if hasattr(attr, '_route_info'):
                route_info = attr._route_info
                
                # Create endpoint function
                def create_endpoint(method_name: str):
                    async def endpoint(request, **kwargs):
                        instance = view_class(request=request)
                        method = getattr(instance, method_name)
                        
                        await instance.initial(request)
                        
                        if inspect.iscoroutinefunction(method):
                            response = await method(**kwargs)
                        else:
                            response = method(**kwargs)
                        
                        return await instance.finalize_response(response)
                    
                    return endpoint
                
                endpoint_func = create_endpoint(attr_name)
                
                router.add_api_route(
                    path=route_info['path'],
                    endpoint=endpoint_func,
                    methods=route_info['methods'],
                    name=route_info['name'] or f"{view_class.__name__.lower()}_{attr_name}",
                    dependencies=route_info.get('dependencies')
                )


def create_router_for_model(
    model_class,
    viewset_class: Type[ViewSetMixin],
    prefix: str,
    *,
    basename: Optional[str] = None,
    tags: Optional[List[str]] = None,
    dependencies: Optional[List[Depends]] = None
) -> CBVRouter:
    """
    Create a router with standard CRUD routes for a model.
    
    This is a convenience function that creates a router and registers
    all the standard REST routes for a model.
    
    Args:
        model_class: The Tortoise ORM model class
        viewset_class: The ViewSet class to handle requests
        prefix: URL prefix (e.g., "/users")
        basename: Base name for routes
        tags: OpenAPI tags
        dependencies: Common dependencies
    
    Returns:
        A configured CBVRouter with all routes registered
    
    Example:
        router = create_router_for_model(
            User, UserViewSet, "/users", 
            tags=["users"], basename="user"
        )
    """
    if basename is None:
        basename = model_class.__name__.lower()
    
    if tags is None:
        tags = [basename]
    
    router = CBVRouter(prefix=prefix, tags=tags, dependencies=dependencies)
    router.add_viewset_routes(viewset_class, basename=basename)
    
    return router