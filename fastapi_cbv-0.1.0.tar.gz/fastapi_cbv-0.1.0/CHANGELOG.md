# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial implementation of FastAPI CBV
- Django REST Framework style class-based views
- Full async support with Tortoise ORM integration
- APIView and GenericAPIView base classes
- Complete set of mixins (CreateModelMixin, ListModelMixin, etc.)
- Generic view classes (ListCreateAPIView, RetrieveUpdateDestroyAPIView, etc.)
- ModelViewSet and ReadOnlyModelViewSet
- @cbv decorator for easy view registration
- CBVRouter with enhanced functionality
- Automatic Pydantic serializer generation from Tortoise models
- Built-in pagination support with TortoisePagination class
- Filtering and search backends
- Comprehensive examples and documentation
- Default configuration values for common settings
- Customizable datetime and date formatting support

### Changed
- Set default `lookup_field = "id"` in GenericAPIView (no need to define repeatedly)
- Set default `datetime_format = "%Y-%m-%d %H:%M:%S"` for consistent datetime serialization
- Set default `date_format = "%Y-%m-%d"` for consistent date serialization
- Improved ListModelMixin to properly implement pagination logic

### Fixed
- Fixed pagination not working in ListModelMixin.list() method
- Fixed datetime serialization issues with custom format support

## [0.1.0] - 2024-01-01

### Added
- Initial release
- Core class-based view functionality
- Tortoise ORM integration
- Documentation and examples