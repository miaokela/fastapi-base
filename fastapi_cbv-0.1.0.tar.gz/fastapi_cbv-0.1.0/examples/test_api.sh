#!/bin/bash
# 简单的 API 测试脚本

BASE_URL="http://localhost:8000"
API_BASE="${BASE_URL}/api/v1"

echo "🧪 FastAPI CBV API 测试"
echo "=" | awk '{s=sprintf("%80s", " "); gsub(" ", "=", s); print s}'
echo

# 等待服务器启动
echo "⏳ 等待服务器启动..."
sleep 3

# 1. 健康检查
echo "1️⃣  健康检查"
curl -s "${BASE_URL}/health" | python3 -m json.tool
echo -e "\n"

# 2. Hello World
echo "2️⃣  Hello World GET"
curl -s "${API_BASE}/hello" | python3 -m json.tool
echo -e "\n"

# 3. 用户统计（初始）
echo "3️⃣  用户统计（初始）"
curl -s "${API_BASE}/users/stats" | python3 -m json.tool
echo -e "\n"

# 4. 创建用户
echo "4️⃣  创建用户"
USER1=$(curl -s -X POST "${API_BASE}/users" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "testuser1",
    "email": "test1@example.com",
    "full_name": "Test User One",
    "is_active": true
  }')
echo $USER1 | python3 -m json.tool
echo -e "\n"

# 5. 列出所有用户
echo "5️⃣  列出所有用户"
curl -s "${API_BASE}/users" | python3 -m json.tool
echo -e "\n"

# 6. 列出所有文章（应该为空）
echo "6️⃣  列出所有文章（初始）"
curl -s "${API_BASE}/posts/" | python3 -m json.tool
echo -e "\n"

# 7. 创建文章
echo "7️⃣  创建文章"
POST1=$(curl -s -X POST "${API_BASE}/posts/" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Post",
    "content": "This is a test post created via API",
    "author": 1,
    "published": true
  }')
echo $POST1 | python3 -m json.tool
echo -e "\n"

# 8. 列出所有文章
echo "8️⃣  列出所有文章"
curl -s "${API_BASE}/posts/" | python3 -m json.tool
echo -e "\n"

# 9. 最终用户统计
echo "9️⃣  用户统计（最终）"
curl -s "${API_BASE}/users/stats" | python3 -m json.tool
echo -e "\n"

echo "=" | awk '{s=sprintf("%80s", " "); gsub(" ", "=", s); print s}'
echo "✅ 测试完成！"