"""
测试默认配置功能
"""
from fastapi import FastAPI
from tortoise.contrib.fastapi import register_tortoise
from tortoise.models import Model
from tortoise import fields

from fastapi_cbv import (
    ListCreateAPIView,
    RetrieveUpdateDestroyAPIView,
    CBVRouter,
    create_tortoise_serializer,
)

app = FastAPI(title="Default Config Test")
router = CBVRouter()


# 定义模型
class TestUser(Model):
    id = fields.IntField(pk=True)
    username = fields.CharField(max_length=50)
    created_at = fields.DatetimeField(auto_now_add=True)
    birth_date = fields.DateField(null=True)

    class Meta:
        table = "test_users"


# 创建序列化器
UserCreateSerializer = create_tortoise_serializer(
    TestUser, name="TestUserCreate", exclude=["id", "created_at"]
)
UserReadSerializer = create_tortoise_serializer(TestUser, name="TestUserRead")


# 测试视图 - 不定义任何默认配置项
class UserListView(ListCreateAPIView):
    """测试默认配置 - 只定义必需的 serializer_class"""
    serializer_class = UserReadSerializer
    
    def get_queryset(self):
        return TestUser.all()
    
    def get_serializer_class(self):
        if self.request.method == "POST":
            return UserCreateSerializer
        return UserReadSerializer


class UserDetailView(RetrieveUpdateDestroyAPIView):
    """测试默认配置 - 只定义必需的 serializer_class"""
    serializer_class = UserReadSerializer
    
    def get_queryset(self):
        return TestUser.all()
    
    def get_serializer_class(self):
        if self.request.method in ["PUT", "PATCH"]:
            return UserCreateSerializer
        return UserReadSerializer


# 注册路由
router.add_cbv_route("/users", UserListView)
router.add_cbv_route("/users/{id}", UserDetailView)

app.include_router(router, prefix="/api")


# 注册数据库
register_tortoise(
    app,
    db_url="sqlite://:memory:",
    modules={"models": [__name__]},
    generate_schemas=True,
    add_exception_handlers=True,
)


if __name__ == "__main__":
    import uvicorn
    print("✅ 测试默认配置:")
    print("   - lookup_field 默认为 'id'")
    print("   - datetime_format 默认为 '%Y-%m-%d %H:%M:%S'")
    print("   - date_format 默认为 '%Y-%m-%d'")
    print("\n🚀 启动测试服务器...")
    print("📖 访问: http://localhost:8001/docs")
    uvicorn.run(app, host="0.0.0.0", port=8001)
