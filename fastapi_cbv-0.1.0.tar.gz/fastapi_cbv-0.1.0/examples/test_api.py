#!/usr/bin/env python3
"""
Test script for FastAPI CBV Example API

This script tests the API endpoints to ensure they're working correctly.
"""

import requests
import json
import time

BASE_URL = "http://localhost:8000"

def test_endpoint(method, endpoint, data=None, expected_status=200):
    """Test an API endpoint"""
    url = f"{BASE_URL}{endpoint}"
    
    try:
        if method.upper() == "GET":
            response = requests.get(url)
        elif method.upper() == "POST":
            response = requests.post(url, json=data)
        else:
            print(f"❌ Unsupported method: {method}")
            return False
        
        if response.status_code == expected_status:
            print(f"✅ {method} {endpoint} - Status: {response.status_code}")
            if response.headers.get('content-type', '').startswith('application/json'):
                result = response.json()
                print(f"   Response: {json.dumps(result, indent=2)}")
            return True
        else:
            print(f"❌ {method} {endpoint} - Expected: {expected_status}, Got: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
    
    except requests.exceptions.ConnectionError:
        print(f"❌ {method} {endpoint} - Connection failed. Is the server running?")
        return False
    except Exception as e:
        print(f"❌ {method} {endpoint} - Error: {e}")
        return False

def main():
    """Run API tests"""
    print("🧪 Testing FastAPI CBV Example API")
    print("=" * 50)
    
    # Wait a moment for server to be ready
    print("Waiting for server to be ready...")
    time.sleep(2)
    
    tests = [
        # Basic endpoints
        ("GET", "/", 200),
        ("GET", "/health", 200),
        ("GET", "/docs", 200),
        
        # CBV endpoints
        ("GET", "/api/v1/hello", 200),
        ("POST", "/api/v1/hello", 200, {"test": "data"}),
        ("GET", "/api/v1/users/stats", 200),
        ("GET", "/api/v1/users", 200),
        ("GET", "/api/v1/posts/", 200),
        
        # Protected endpoint (might fail without auth)
        ("GET", "/api/v1/protected", 422),  # Expect 422 due to missing dependency
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if len(test) == 4:
            method, endpoint, status, data = test
            if test_endpoint(method, endpoint, data, status):
                passed += 1
        else:
            method, endpoint, status = test
            if test_endpoint(method, endpoint, expected_status=status):
                passed += 1
        print()
    
    print("=" * 50)
    print(f"🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! FastAPI CBV is working correctly!")
    else:
        print(f"⚠️  {total - passed} tests failed. Check the server logs.")

if __name__ == "__main__":
    main()