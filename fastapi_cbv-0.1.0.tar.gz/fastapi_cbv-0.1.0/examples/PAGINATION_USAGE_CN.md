# FastAPI-CBV 分页使用指南

## 快速开始

### 1. 基本配置

在你的视图类中设置 `pagination_class`：

```python
from fastapi_cbv.tortoise_integration import TortoisePagination
from fastapi_cbv.views import ListCreateAPIView

class UserListView(ListCreateAPIView):
    serializer_class = UserSerializer
    pagination_class = TortoisePagination  # 启用分页
    
    def get_queryset(self):
        return User.all()
```

### 2. 使用默认分页

**请求：**
```bash
GET /api/users
```

**响应：**
```json
{
    "count": 100,        // 总记录数
    "page": 1,           // 当前页码
    "page_size": 20,     // 每页记录数（默认 20）
    "total_pages": 5,    // 总页数
    "next": true,        // 是否有下一页
    "previous": false,   // 是否有上一页
    "results": [...]     // 当前页的数据
}
```

### 3. 自定义分页参数

**请求第2页，每页10条：**
```bash
GET /api/users?page=2&page_size=10
```

**响应：**
```json
{
    "count": 100,
    "page": 2,
    "page_size": 10,
    "total_pages": 10,
    "next": true,
    "previous": true,
    "results": [...]     // 第11-20条记录
}
```

## 配置选项

### 自定义分页类

你可以创建自己的分页类：

```python
from fastapi_cbv.tortoise_integration import TortoisePagination

class CustomPagination(TortoisePagination):
    def __init__(self):
        super().__init__(
            page_size=50,              # 默认每页50条
            page_size_query_param='size',  # 使用 'size' 参数而不是 'page_size'
            max_page_size=200          # 最大每页200条
        )

class UserListView(ListCreateAPIView):
    pagination_class = CustomPagination
    # ...
```

### 禁用分页

如果某个视图不需要分页，设置为 `None`：

```python
class AllUsersView(ListCreateAPIView):
    pagination_class = None  # 禁用分页，返回所有记录
    # ...
```

## 完整示例

```python
from fastapi import FastAPI
from fastapi_cbv import cbv_router
from fastapi_cbv.views import ListCreateAPIView
from fastapi_cbv.tortoise_integration import TortoisePagination
from models import User
from schemas import UserSerializer

app = FastAPI()
router = cbv_router()

class UserListView(ListCreateAPIView):
    """用户列表视图（带分页）"""
    serializer_class = UserSerializer
    pagination_class = TortoisePagination
    
    def get_queryset(self):
        return User.all()

# 注册路由
router.add_cbv_route("/users", UserListView)
app.include_router(router, prefix="/api")

# 测试端点：
# GET /api/users                      - 第1页，20条记录
# GET /api/users?page=2               - 第2页，20条记录
# GET /api/users?page=1&page_size=5   - 第1页，5条记录
```

## ViewSet 分页

ViewSet 也支持分页：

```python
from fastapi_cbv.views import ModelViewSet

class PostViewSet(ModelViewSet):
    """文章 ViewSet（带分页）"""
    serializer_class = PostSerializer
    pagination_class = TortoisePagination
    
    def get_queryset(self):
        return Post.all()

# 自动生成的路由都支持分页：
# GET /posts/     - 列表端点（带分页）
# GET /posts/{id} - 详情端点（不分页）
```

## 前端集成示例

### JavaScript/Fetch
```javascript
async function fetchUsers(page = 1, pageSize = 20) {
    const response = await fetch(
        `http://localhost:8000/api/users?page=${page}&page_size=${pageSize}`
    );
    const data = await response.json();
    
    console.log(`显示第 ${data.page} 页，共 ${data.total_pages} 页`);
    console.log(`总共 ${data.count} 条记录`);
    console.log('数据:', data.results);
    
    return data;
}

// 使用
fetchUsers(1, 10);
```

### Vue 3 示例
```vue
<template>
  <div>
    <div v-for="user in users" :key="user.id">
      {{ user.username }}
    </div>
    
    <div class="pagination">
      <button @click="prevPage" :disabled="!hasPrevious">上一页</button>
      <span>第 {{ currentPage }} 页，共 {{ totalPages }} 页</span>
      <button @click="nextPage" :disabled="!hasNext">下一页</button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const users = ref([]);
const currentPage = ref(1);
const totalPages = ref(1);
const hasNext = ref(false);
const hasPrevious = ref(false);

async function loadUsers(page = 1) {
  const response = await fetch(
    `http://localhost:8000/api/users?page=${page}&page_size=10`
  );
  const data = await response.json();
  
  users.value = data.results;
  currentPage.value = data.page;
  totalPages.value = data.total_pages;
  hasNext.value = data.next;
  hasPrevious.value = data.previous;
}

function nextPage() {
  if (hasNext.value) loadUsers(currentPage.value + 1);
}

function prevPage() {
  if (hasPrevious.value) loadUsers(currentPage.value - 1);
}

// 初始加载
loadUsers();
</script>
```

## 常见问题

### 1. 分页返回普通数组而不是分页对象？

**原因：** 没有设置 `pagination_class`。

**解决：**
```python
class MyView(ListCreateAPIView):
    pagination_class = TortoisePagination  # 添加这一行
```

### 2. 如何修改默认每页数量？

```python
class MyPagination(TortoisePagination):
    def __init__(self):
        super().__init__(page_size=50)  # 默认50条

class MyView(ListCreateAPIView):
    pagination_class = MyPagination
```

### 3. 如何限制最大每页数量？

```python
class MyPagination(TortoisePagination):
    def __init__(self):
        super().__init__(
            page_size=20,
            max_page_size=100  # 最多100条
        )
```

### 4. 分页参数是什么？

- `page`: 页码，从 1 开始
- `page_size`: 每页记录数，默认 20

### 5. 如何结合过滤和分页？

```python
# 自动支持！过滤后的结果会自动分页
GET /api/users?is_active=true&page=1&page_size=10
```

## 测试示例

使用 `pagination_test.http` 文件测试：

```http
### 基本分页测试
GET http://localhost:8000/api/v1/users?page=1&page_size=5

### 第二页
GET http://localhost:8000/api/v1/users?page=2&page_size=5

### 大页面尺寸
GET http://localhost:8000/api/v1/users?page=1&page_size=100

### 默认分页
GET http://localhost:8000/api/v1/users
```

## 总结

✅ **优点：**
- 自动处理分页逻辑
- 统一的响应格式
- 灵活的配置选项
- 支持自定义分页类
- 前后端友好的API设计

🎯 **最佳实践：**
- 始终为列表视图启用分页
- 设置合理的 `max_page_size` 防止过大请求
- 在API文档中说明分页参数
- 前端缓存分页数据提高性能
