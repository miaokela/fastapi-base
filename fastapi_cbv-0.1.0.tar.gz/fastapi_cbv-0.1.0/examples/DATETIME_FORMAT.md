# DateTime 格式化设置指南

## 快速开始

在任何视图类中添加 `datetime_format` 和 `date_format` 属性即可自定义时间格式：

```python
class UserListView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    # 设置 datetime 格式为：年-月-日 时:分:秒
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 输出: 2025-10-04 10:30:45
    date_format = "%Y-%m-%d"                # 输出: 2025-10-04
```

## 常用格式

### 1. 标准格式（推荐）
```python
datetime_format = "%Y-%m-%d %H:%M:%S"
# 输出: 2025-10-04 10:30:45
```

### 2. 中文格式
```python
datetime_format = "%Y年%m月%d日 %H:%M:%S"
# 输出: 2025年10月04日 10:30:45

date_format = "%Y年%m月%d日"
# 输出: 2025年10月04日
```

### 3. 简短格式（不含秒）
```python
datetime_format = "%Y-%m-%d %H:%M"
# 输出: 2025-10-04 10:30
```

### 4. 美式格式（12小时制）
```python
datetime_format = "%m/%d/%Y %I:%M:%S %p"
# 输出: 10/04/2025 10:30:45 AM
```

### 5. 欧式格式
```python
datetime_format = "%d/%m/%Y %H:%M:%S"
# 输出: 04/10/2025 10:30:45
```

### 6. 仅日期
```python
date_format = "%Y-%m-%d"      # 2025-10-04
date_format = "%d/%m/%Y"      # 04/10/2025
date_format = "%Y年%m月%d日"  # 2025年10月04日
```

### 7. ISO 格式（默认）
```python
# 不设置或设置为 None，使用默认 ISO 格式
datetime_format = None
# 输出: 2025-10-04T10:30:45.123456+00:00
```

## 格式符号说明

| 符号 | 说明 | 示例 |
|------|------|------|
| `%Y` | 四位年份 | 2025 |
| `%y` | 两位年份 | 25 |
| `%m` | 月份 (01-12) | 10 |
| `%d` | 日期 (01-31) | 04 |
| `%H` | 小时 24小时制 (00-23) | 14 |
| `%I` | 小时 12小时制 (01-12) | 02 |
| `%M` | 分钟 (00-59) | 30 |
| `%S` | 秒 (00-59) | 45 |
| `%f` | 微秒 (000000-999999) | 123456 |
| `%p` | AM/PM | PM |
| `%z` | UTC 偏移 | +0800 |
| `%Z` | 时区名称 | CST |

## 完整示例

```python
from fastapi_cbv import ListCreateAPIView, RetrieveUpdateDestroyAPIView

# 列表视图：使用简洁格式
class UserListView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    datetime_format = "%Y-%m-%d %H:%M"  # 简洁格式
    date_format = "%Y-%m-%d"


# 详情视图：使用完整格式
class UserDetailView(RetrieveUpdateDestroyAPIView):
    model = User
    serializer_class = UserSerializer
    
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 完整格式
    date_format = "%Y-%m-%d"


# ViewSet：统一使用标准格式
class PostViewSet(ModelViewSet):
    model = Post
    serializer_class = PostSerializer
    
    datetime_format = "%Y-%m-%d %H:%M:%S"
    date_format = "%Y-%m-%d"
```

## 高级用法

### 不同字段使用不同格式

```python
class AdvancedView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    def _model_to_dict(self, instance, serializer_class):
        from tortoise import fields as tortoise_fields
        from datetime import datetime, date
        
        data = {}
        model_class = type(instance)
        serializer_fields = serializer_class.model_fields.keys() if hasattr(
            serializer_class, 'model_fields'
        ) else model_class._meta.fields_map.keys()
        
        for field_name in serializer_fields:
            if field_name in model_class._meta.fields_map:
                field_obj = model_class._meta.fields_map[field_name]
                
                if isinstance(field_obj, tortoise_fields.relational.ForeignKeyFieldInstance):
                    fk_id_attr = f"{field_name}_id"
                    data[field_name] = getattr(instance, fk_id_attr) if hasattr(
                        instance, fk_id_attr
                    ) else None
                else:
                    if hasattr(instance, field_name):
                        value = getattr(instance, field_name)
                        
                        # 针对不同字段使用不同格式
                        if isinstance(value, datetime):
                            if field_name == 'created_at':
                                value = value.strftime("%Y-%m-%d %H:%M:%S")
                            elif field_name == 'updated_at':
                                value = value.strftime("%Y-%m-%d %H:%M")
                            elif field_name == 'last_login':
                                value = value.strftime("%Y年%m月%d日")
                            else:
                                value = value.isoformat()
                        elif isinstance(value, date):
                            value = value.strftime("%Y-%m-%d")
                        
                        data[field_name] = value
        
        return data
```

### 返回 Unix 时间戳

```python
class TimestampView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    def _model_to_dict(self, instance, serializer_class):
        # ... 省略部分代码 ...
        
        if isinstance(value, datetime):
            # 返回 Unix 时间戳（秒）
            value = int(value.timestamp())
        elif isinstance(value, date):
            from datetime import datetime as dt
            value = int(dt.combine(value, dt.min.time()).timestamp())
        
        # ... 省略部分代码 ...
```

## 测试效果

启动服务器后，访问 API 端点查看效果：

```bash
# 标准格式
curl http://localhost:8000/api/v1/users/1
{
    "id": 1,
    "username": "john",
    "created_at": "2025-10-04 10:30:45",
    "updated_at": "2025-10-04 10:30:45"
}

# 中文格式
curl http://localhost:8000/api/v1/posts/1
{
    "id": 1,
    "title": "标题",
    "created_at": "2025年10月04日 10:30:45",
    "updated_at": "2025年10月04日 10:30:45"
}
```

## 常见问题

**Q: 如果不设置会怎样？**  
A: 默认使用 ISO 8601 格式：`2025-10-04T10:30:45.123456+00:00`

**Q: 可以只设置部分视图吗？**  
A: 可以！每个视图类都可以有独立的配置。

**Q: datetime_format 和 date_format 的区别？**  
A: `datetime_format` 用于 `DatetimeField`，`date_format` 用于 `DateField`。

**Q: 如何显示毫秒？**  
A: 使用 `%f` 显示微秒（6位）：
```python
datetime_format = "%Y-%m-%d %H:%M:%S.%f"
# 输出: 2025-10-04 10:30:45.123456
```

**Q: 如何适应不同环境？**  
A: 通过环境变量动态设置：
```python
import os

class UserView(ListCreateAPIView):
    datetime_format = os.getenv("DATETIME_FORMAT", "%Y-%m-%d %H:%M:%S")
```

## 更多示例

查看以下文件获取更多示例：
- `examples/complete_example.py` - 完整示例
- `examples/datetime_format_example.py` - 各种格式示例
- `examples/DATETIME_FORMAT_GUIDE.py` - 详细指南
