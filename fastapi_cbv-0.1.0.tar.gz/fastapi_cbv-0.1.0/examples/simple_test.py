"""
Simple test for FastAPI CBV
"""

from fastapi import FastAPI
from fastapi_cbv import APIView, cbv, CBVRouter

# Initialize FastAPI app
app = FastAPI(title="FastAPI CBV Test", version="1.0.0")

# Initialize router
router = CBVRouter()

# Simple APIView test
@cbv(router)
class HelloView(APIView):
    """Simple API view example"""
    
    async def get(self):
        return {"message": "Hello from FastAPI CBV!"}
    
    async def post(self):
        data = await self.request.json()
        return {"echo": data}

# Register routes
HelloView.add_api_route("/hello")

# Include router in app
app.include_router(router, prefix="/api/v1")

# Root endpoint
@app.get("/")
async def root():
    return {"message": "FastAPI CBV Test API"}

if __name__ == "__main__":
    import uvicorn
    print("Starting FastAPI CBV test server...")
    print("Visit http://localhost:8000/docs for API documentation")
    print("Visit http://localhost:8000/api/v1/hello for the hello endpoint")
    uvicorn.run(app, host="0.0.0.0", port=8000)