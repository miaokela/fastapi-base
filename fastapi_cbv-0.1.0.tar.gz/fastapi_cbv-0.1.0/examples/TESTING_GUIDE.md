# FastAPI CBV API 完整测试指南

## 📋 测试前准备

### 1. 启动服务器

```bash
cd /Users/kela/Program/Other/Py/fastapi-cbv
uv run python examples/complete_example.py
```

服务器将在 `http://localhost:8000` 启动。

### 2. 访问 API 文档

打开浏览器访问：
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## 🧪 使用 .http 文件测试

### 方法 1: VS Code REST Client

1. 安装扩展：在 VS Code 中搜索并安装 "REST Client"
2. 打开 `examples/crud_test.http` 或 `examples/api_test.http`
3. 点击请求上方的 **"Send Request"** 链接
4. 查看响应

### 方法 2: 使用命令行工具

```bash
# 运行自动化测试脚本
cd examples
chmod +x test_api.sh
./test_api.sh
```

## 📝 完整测试流程（按顺序执行）

### 步骤 1: 健康检查

```http
GET http://localhost:8000/health
```

预期响应：
```json
{
  "status": "healthy",
  "version": "1.0.0"
}
```

### 步骤 2: 测试简单 APIView

```http
GET http://localhost:8000/api/v1/hello
```

预期响应：
```json
{
  "message": "Hello from FastAPI CBV!"
}
```

### 步骤 3: 查看初始用户统计

```http
GET http://localhost:8000/api/v1/users/stats
```

预期响应：
```json
{
  "total_users": 0,
  "active_users": 0,
  "inactive_users": 0
}
```

### 步骤 4: 创建用户（重要：必须先创建用户才能创建文章）

```http
POST http://localhost:8000/api/v1/users
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "full_name": "John Doe",
  "is_active": true
}
```

预期响应：
```json
{
  "id": 1,
  "username": "john_doe",
  "email": "john@example.com",
  "full_name": "John Doe",
  "is_active": true,
  "created_at": "2025-10-04T...",
  "updated_at": "2025-10-04T..."
}
```

### 步骤 5: 创建更多用户

```http
POST http://localhost:8000/api/v1/users
Content-Type: application/json

{
  "username": "jane_smith",
  "email": "jane@example.com",
  "full_name": "Jane Smith",
  "is_active": true
}
```

### 步骤 6: 列出所有用户

```http
GET http://localhost:8000/api/v1/users
```

### 步骤 7: 创建文章（使用已存在的用户 ID）

⚠️ **重要**: `author` 字段必须是已存在用户的 ID！

```http
POST http://localhost:8000/api/v1/posts/
Content-Type: application/json

{
  "title": "My First Post",
  "content": "This is my first post using FastAPI CBV!",
  "author": 1,
  "published": true
}
```

### 步骤 8: 列出所有文章

```http
GET http://localhost:8000/api/v1/posts/
```

### 步骤 9: 获取特定文章

```http
GET http://localhost:8000/api/v1/posts/1/
```

### 步骤 10: 更新文章

```http
PUT http://localhost:8000/api/v1/posts/1/
Content-Type: application/json

{
  "title": "Updated Title",
  "content": "Updated content",
  "author": 1,
  "published": true
}
```

### 步骤 11: 部分更新文章

```http
PATCH http://localhost:8000/api/v1/posts/1/
Content-Type: application/json

{
  "published": false
}
```

### 步骤 12: 删除资源

```http
DELETE http://localhost:8000/api/v1/posts/1/
```

```http
DELETE http://localhost:8000/api/v1/users/2
```

## ⚠️ 常见错误和解决方案

### 错误 1: FOREIGN KEY constraint failed

**原因**: 尝试创建文章时，指定的 `author` ID 不存在

**解决方案**: 
1. 先创建用户
2. 记住用户的 ID（从响应中获取）
3. 使用该 ID 创建文章

### 错误 2: 422 Unprocessable Entity

**原因**: 请求数据验证失败

**解决方案**: 检查：
- 必填字段是否都提供了
- 数据类型是否正确
- Email 格式是否有效
- 用户名是否唯一

### 错误 3: 404 Not Found

**原因**: 请求的资源不存在

**解决方案**: 
- 检查 ID 是否正确
- 确认资源尚未被删除

### 错误 4: 500 Internal Server Error

**原因**: 服务器内部错误

**解决方案**: 
- 查看服务器终端的错误日志
- 检查数据库连接是否正常

## 🎯 推荐测试顺序

1. **基础功能测试**
   - ✅ 健康检查
   - ✅ Hello World
   - ✅ 用户统计

2. **用户 CRUD**
   - ✅ 创建 3-4 个用户
   - ✅ 列出所有用户
   - ✅ 获取单个用户
   - ✅ 更新用户
   - ✅ 部分更新用户

3. **文章 CRUD**（确保已有用户）
   - ✅ 为不同用户创建多篇文章
   - ✅ 列出所有文章
   - ✅ 获取单个文章
   - ✅ 更新文章
   - ✅ 删除文章

4. **高级功能**
   - ✅ 按作者过滤文章
   - ✅ 搜索功能
   - ✅ 排序

## 📊 数据关系说明

```
User (用户)
├── id: int (主键)
├── username: string (唯一)
├── email: string (唯一)
├── full_name: string
├── is_active: boolean
├── created_at: datetime
└── updated_at: datetime

Post (文章)
├── id: int (主键)
├── title: string
├── content: string
├── author: int (外键 -> User.id)  ⚠️ 重要：必须是已存在的用户 ID
├── published: boolean
├── created_at: datetime
└── updated_at: datetime
```

## 🔗 快速链接

- 📖 API 文档: http://localhost:8000/docs
- 🔍 ReDoc: http://localhost:8000/redoc
- ❤️ 健康检查: http://localhost:8000/health
- 🏠 根路径: http://localhost:8000/

## 💡 提示

1. **使用 Swagger UI 测试**: 访问 `/docs` 可以直接在浏览器中测试 API，无需额外工具
2. **保存用户 ID**: 创建用户后，记录返回的 ID，以便创建文章时使用
3. **查看实时日志**: 服务器终端会显示所有请求和错误信息
4. **数据持久化**: 数据存储在 `test.db` SQLite 文件中，重启服务器后数据仍然存在
5. **清空数据库**: 删除 `test.db` 文件可以重新开始

## 🎉 示例：完整的工作流程

```http
# 1. 创建第一个用户
POST http://localhost:8000/api/v1/users
Content-Type: application/json

{
  "username": "alice",
  "email": "alice@example.com",
  "full_name": "Alice Johnson",
  "is_active": true
}

# 2. 创建第二个用户
POST http://localhost:8000/api/v1/users
Content-Type: application/json

{
  "username": "bob",
  "email": "bob@example.com",
  "full_name": "Bob Smith",
  "is_active": true
}

# 3. Alice 创建一篇文章
POST http://localhost:8000/api/v1/posts/
Content-Type: application/json

{
  "title": "Welcome to FastAPI CBV",
  "content": "This is Alice's first post!",
  "author": 1,
  "published": true
}

# 4. Bob 创建一篇文章
POST http://localhost:8000/api/v1/posts/
Content-Type: application/json

{
  "title": "Getting Started",
  "content": "Bob's guide to FastAPI CBV",
  "author": 2,
  "published": true
}

# 5. 查看所有文章
GET http://localhost:8000/api/v1/posts/

# 6. 只看 Alice 的文章
GET http://localhost:8000/api/v1/posts/?author=1

# 7. 更新 Alice 的文章
PUT http://localhost:8000/api/v1/posts/1/
Content-Type: application/json

{
  "title": "Welcome to FastAPI CBV (Updated)",
  "content": "This is Alice's updated post!",
  "author": 1,
  "published": true
}
```

现在你可以按照这个指南进行完整的 API 测试了！🚀