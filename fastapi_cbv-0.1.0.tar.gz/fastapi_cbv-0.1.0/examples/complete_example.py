"""
Complete example demonstrating FastAPI CBV usage

This example shows how to use the fastapi-cbv library to create
Django REST Framework style APIs with FastAPI and Tortoise ORM.
"""

from fastapi import FastAPI, Depends
from tortoise.contrib.fastapi import register_tortoise
from tortoise.models import Model
from tortoise import fields
from pydantic import BaseModel
from typing import Optional, List

# Import our CBV components
from fastapi_cbv import (
    APIView,
    GenericAPIView,
    ListCreateAPIView,
    RetrieveUpdateDestroyAPIView,
    ModelViewSet,
    cbv,
    CBVRouter,
    create_tortoise_serializer,
    TortoisePagination,
    TortoiseFilterBackend,
    viewset_routes,
)

# Initialize FastAPI app
app = FastAPI(title="FastAPI CBV Example", version="1.0.0")

# Initialize router
router = CBVRouter()


# Define Tortoise ORM models
class User(Model):
    id = fields.IntField(pk=True)
    username = fields.CharField(max_length=50, unique=True)
    email = fields.CharField(max_length=100, unique=True)
    full_name = fields.CharField(max_length=100, null=True)
    is_active = fields.BooleanField(default=True)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "users"


class Post(Model):
    id = fields.IntField(pk=True)
    title = fields.CharField(max_length=200)
    content = fields.TextField()
    author = fields.ForeignKeyField("models.User", related_name="posts")
    published = fields.BooleanField(default=False)
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "posts"


# Create Pydantic serializers
UserCreateSerializer = create_tortoise_serializer(
    User, name="UserCreate", exclude=["id", "created_at", "updated_at"]
)

UserReadSerializer = create_tortoise_serializer(User, name="UserRead")

PostCreateSerializer = create_tortoise_serializer(
    Post, name="PostCreate", exclude=["id", "created_at", "updated_at"]
)

PostReadSerializer = create_tortoise_serializer(Post, name="PostRead")


# Example 1: Simple APIView
@cbv(router)
class HelloWorldView(APIView):
    """Simple API view example"""

    async def get(self):
        return {"message": "Hello from FastAPI CBV!"}

    async def post(self):
        data = await self.request.json()
        return {"echo": data}


# Example 2: Generic views for User model
class UserListCreateView(ListCreateAPIView):
    """List and create users"""

    # queryset = User.all()  # Will be set in get_queryset method
    serializer_class = UserReadSerializer
    filter_backends = [TortoiseFilterBackend]
    pagination_class = TortoisePagination

    def get_queryset(self):
        return User.all()

    def get_serializer_class(self):
        if self.request.method == "POST":
            return UserCreateSerializer
        return UserReadSerializer


class UserDetailView(RetrieveUpdateDestroyAPIView):
    """Retrieve, update, and delete users"""

    # queryset = User.all()  # Will be set in get_queryset method
    serializer_class = UserReadSerializer

    def get_queryset(self):
        return User.all()

    def get_serializer_class(self):
        if self.request.method in ["PUT", "PATCH"]:
            return UserCreateSerializer
        return UserReadSerializer


# Example 3: ViewSet for Post model
class PostViewSet(ModelViewSet):
    """Complete CRUD operations for posts"""

    # queryset = Post.all().select_related('author')  # Will be set in get_queryset method
    serializer_class = PostReadSerializer
    filter_backends = [TortoiseFilterBackend]
    pagination_class = TortoisePagination
    search_fields = ["title", "content"]
    ordering_fields = ["created_at", "title"]
    ordering = ["-created_at"]

    def get_queryset(self):
        """Get queryset with optional author filtering"""
        queryset = Post.all().select_related("author")

        # Filter by author if specified in query params
        if hasattr(self, "request") and hasattr(self.request, "query_params"):
            author_id = self.request.query_params.get("author")
            if author_id:
                queryset = queryset.filter(author_id=author_id)

        return queryset

    def get_serializer_class(self):
        if self.request.method in ["POST", "PUT", "PATCH"]:
            return PostCreateSerializer
        return PostReadSerializer


# Example 4: Custom actions with method decorators
@cbv(router)
class UserStatsView(GenericAPIView):
    """Custom view with multiple endpoints"""

    async def get(self):
        """Get user statistics"""
        total_users = await User.all().count()
        active_users = await User.filter(is_active=True).count()

        return {
            "total_users": total_users,
            "active_users": active_users,
            "inactive_users": total_users - active_users,
        }


# Register routes

# Method 1: Manual route registration
HelloWorldView.add_api_route("/hello")
UserStatsView.add_api_route("/users/stats")

# Method 2: Using CBVRouter methods
router.add_cbv_route("/users", UserListCreateView)
router.add_cbv_route("/users/{id}", UserDetailView)

# Method 3: ViewSet with automatic route generation
viewset_routes(
    router=router, viewset_class=PostViewSet, prefix="/posts", basename="post"
)


# Example 5: Custom dependency injection
async def get_current_user():
    """Dependency to get current user (mock implementation)"""
    # In a real app, this would validate JWT token, etc.
    return {"user_id": 1, "username": "testuser"}


@cbv(router)
class ProtectedView(APIView):
    """Example of view with dependencies"""

    async def get(self, current_user: dict = Depends(get_current_user)):
        return {"message": f"Hello {current_user['username']}!"}


ProtectedView.add_api_route("/protected", dependencies=[Depends(get_current_user)])

# Include router in app
app.include_router(router, prefix="/api/v1")

# Add CORS middleware
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register Tortoise ORM
register_tortoise(
    app,
    db_url="sqlite://./test.db",
    modules={"models": [__name__]},
    generate_schemas=True,
    add_exception_handlers=True,
)


# Root endpoint
@app.get("/")
async def root():
    return {"message": "FastAPI CBV Example API"}


# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy", "version": "1.0.0"}


if __name__ == "__main__":
    import uvicorn

    print("🚀 Starting FastAPI CBV Example Server...")
    print("📖 API Documentation: http://localhost:8000/docs")
    print("🔍 Alternative Docs: http://localhost:8000/redoc")
    print("💡 Test Endpoints:")
    print("   - GET  http://localhost:8000/api/v1/hello")
    print("   - GET  http://localhost:8000/api/v1/users/stats")
    print("   - GET  http://localhost:8000/api/v1/users")
    print("   - POST http://localhost:8000/api/v1/posts")
    uvicorn.run(app, host="0.0.0.0", port=8000)
