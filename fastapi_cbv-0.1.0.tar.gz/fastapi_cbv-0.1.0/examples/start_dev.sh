#!/bin/bash

# Development server startup script for FastAPI CBV Example

echo "🚀 Starting FastAPI CBV Example in Development Mode..."
echo "📖 API Documentation: http://localhost:8000/docs"
echo "🔍 Alternative Docs: http://localhost:8000/redoc"
echo "💡 Test Endpoints:"
echo "   - GET  http://localhost:8000/api/v1/hello"
echo "   - GET  http://localhost:8000/api/v1/users/stats"
echo "   - GET  http://localhost:8000/api/v1/users"
echo "   - POST http://localhost:8000/api/v1/posts"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

cd "$(dirname "$0")"
export PYTHONPATH="../:$PYTHONPATH"

# Use the import string format for reload functionality
uvicorn complete_example:app --host 0.0.0.0 --port 8000 --reload