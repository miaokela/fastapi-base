# FastAPI CBV API Testing Guide

这个目录包含了完整的 FastAPI CBV (Class-Based Views) API 测试文件。

## 文件说明

- `api_test.http` - 包含所有 CRUD 操作的 HTTP 请求
- `complete_example.py` - 完整的 FastAPI CBV 示例应用
- `start_dev.sh` - 开发服务器启动脚本

## 如何使用 .http 文件

### 1. 使用 VS Code REST Client 扩展

1. 安装 VS Code 扩展：`REST Client`
2. 启动服务器：
   ```bash
   cd /Users/kela/Program/Other/Py/fastapi-cbv
   uv run python examples/complete_example.py
   ```
3. 打开 `api_test.http` 文件
4. 点击请求上方的 "Send Request" 按钮

### 2. 使用 curl 命令

从 `.http` 文件中复制请求，转换为 curl 命令：

```bash
# 健康检查
curl http://localhost:8000/health

# Hello World API
curl http://localhost:8000/api/v1/hello

# 创建用户
curl -X POST http://localhost:8000/api/v1/users \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "email": "john@example.com", 
    "full_name": "John Doe",
    "is_active": true
  }'

# 列出用户
curl http://localhost:8000/api/v1/users
```

## API 端点概览

### 基础端点
- `GET /` - 根端点
- `GET /health` - 健康检查
- `GET /docs` - API 文档 (Swagger UI)

### CBV 端点
- `GET|POST /api/v1/hello` - 简单的 APIView 示例
- `GET /api/v1/users/stats` - 用户统计信息

### 用户 CRUD (Generic Views)
- `GET /api/v1/users` - 列出所有用户
- `POST /api/v1/users` - 创建新用户
- `GET /api/v1/users/{id}` - 获取特定用户
- `PUT /api/v1/users/{id}` - 更新用户
- `PATCH /api/v1/users/{id}` - 部分更新用户
- `DELETE /api/v1/users/{id}` - 删除用户

### 文章 CRUD (ViewSet)
- `GET /api/v1/posts/` - 列出所有文章
- `POST /api/v1/posts/` - 创建新文章
- `GET /api/v1/posts/{id}/` - 获取特定文章
- `PUT /api/v1/posts/{id}/` - 更新文章
- `PATCH /api/v1/posts/{id}/` - 部分更新文章
- `DELETE /api/v1/posts/{id}/` - 删除文章

### 高级功能
- 过滤：`GET /api/v1/posts/?author=1`
- 搜索：`GET /api/v1/posts/?search=keyword`
- 排序：`GET /api/v1/posts/?ordering=-created_at`

## 测试流程建议

1. **基础测试**
   - 健康检查
   - Hello World API
   - 用户统计

2. **用户 CRUD 测试**
   - 创建多个用户
   - 列出用户
   - 获取单个用户
   - 更新用户
   - 删除用户

3. **文章 CRUD 测试**
   - 创建文章（需要先有用户）
   - 列出文章
   - 获取单个文章
   - 更新文章
   - 删除文章

4. **高级功能测试**
   - 过滤和搜索
   - 错误处理
   - 验证失败

## 数据模型

### User
```json
{
  "username": "string",
  "email": "string",
  "full_name": "string",
  "is_active": true
}
```

### Post
```json
{
  "title": "string",
  "content": "string", 
  "author": 1,
  "published": true
}
```

## 注意事项

- 服务器必须在 `localhost:8000` 运行
- 使用 SQLite 数据库，数据在 `test.db` 文件中
- 第一次运行会自动创建数据库表
- 用户 ID 从 1 开始自增
- 创建文章时需要提供有效的 author ID