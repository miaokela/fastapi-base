# FastAPI-CBV 分页使用指南

## 快速开始

分页功能已经内置在 `TortoisePagination` 类中，使用非常简单：

### 1. 基本用法

```python
from fastapi_cbv import ListCreateAPIView, TortoisePagination

class UserListView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    pagination_class = TortoisePagination  # 启用分页
```

**就这么简单！** 添加 `pagination_class = TortoisePagination` 即可启用分页。

## API 使用

### 请求参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `page` | int | 1 | 页码（从 1 开始） |
| `page_size` | int | 20 | 每页数量 |

### 请求示例

```bash
# 获取第 1 页，每页 10 条
GET /api/v1/users?page=1&page_size=10

# 获取第 2 页，每页 20 条
GET /api/v1/users?page=2&page_size=20

# 获取第 3 页，默认每页 20 条
GET /api/v1/users?page=3
```

### 响应格式

```json
{
    "count": 100,           // 总记录数
    "page": 1,              // 当前页码
    "page_size": 10,        // 每页数量
    "total_pages": 10,      // 总页数
    "next": true,           // 是否有下一页
    "previous": false,      // 是否有上一页
    "results": [            // 当前页的数据
        {
            "id": 1,
            "username": "user1",
            "email": "user1@example.com"
        },
        // ... 更多数据
    ]
}
```

## 自定义分页配置

### 方法 1: 自定义默认参数

```python
class UserListView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    # 自定义分页参数
    pagination_class = TortoisePagination
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 自定义分页设置
        if self.pagination_class:
            self.pagination_class = TortoisePagination(
                page_size=50,           # 默认每页 50 条
                page_size_query_param='size',  # 使用 'size' 参数而不是 'page_size'
                max_page_size=200       # 最大每页 200 条
            )
```

### 方法 2: 创建自定义分页类

```python
class CustomPagination(TortoisePagination):
    """自定义分页类"""
    
    def __init__(self):
        super().__init__(
            page_size=30,              # 默认每页 30 条
            page_size_query_param='per_page',  # 使用 'per_page' 参数
            max_page_size=500          # 最大每页 500 条
        )
    
    def get_paginated_response(self, data):
        """自定义响应格式"""
        return {
            'total': self.total,
            'current_page': self.page,
            'per_page': self.page_size,
            'last_page': self.total_pages,
            'has_more': self.page < self.total_pages,
            'data': data
        }


class UserListView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    pagination_class = CustomPagination
```

## 完整示例

```python
from fastapi import FastAPI
from tortoise import fields
from tortoise.models import Model
from tortoise.contrib.fastapi import register_tortoise

from fastapi_cbv import (
    ListCreateAPIView,
    RetrieveUpdateDestroyAPIView,
    ModelViewSet,
    CBVRouter,
    TortoisePagination,
    create_tortoise_serializer
)

# 定义模型
class User(Model):
    id = fields.IntField(pk=True)
    username = fields.CharField(max_length=50, unique=True)
    email = fields.CharField(max_length=100)
    is_active = fields.BooleanField(default=True)
    created_at = fields.DatetimeField(auto_now_add=True)

    class Meta:
        table = "users"


# 创建序列化器
UserSerializer = create_tortoise_serializer(User)


# 示例 1: 基本分页（默认配置）
class UserListView(ListCreateAPIView):
    """用户列表 - 使用默认分页配置"""
    model = User
    serializer_class = UserSerializer
    pagination_class = TortoisePagination  # 默认: 每页 20 条，最大 100 条


# 示例 2: 自定义分页大小
class CustomPagination(TortoisePagination):
    def __init__(self):
        super().__init__(
            page_size=10,              # 每页 10 条
            page_size_query_param='size',
            max_page_size=50           # 最大 50 条
        )

class PostListView(ListCreateAPIView):
    """文章列表 - 自定义分页"""
    model = Post
    serializer_class = PostSerializer
    pagination_class = CustomPagination


# 示例 3: ViewSet 使用分页
class UserViewSet(ModelViewSet):
    """用户 ViewSet - 自动支持分页"""
    model = User
    serializer_class = UserSerializer
    pagination_class = TortoisePagination


# 示例 4: 禁用分页
class AllUsersView(ListCreateAPIView):
    """获取所有用户 - 不使用分页"""
    model = User
    serializer_class = UserSerializer
    # pagination_class = None  # 不设置或设置为 None 即可禁用分页


# 设置路由
app = FastAPI()
router = CBVRouter()

router.add_cbv_route("/users", UserListView)
router.add_cbv_route("/posts", PostListView)

app.include_router(router, prefix="/api/v1")

# 注册 Tortoise ORM
register_tortoise(
    app,
    db_url="sqlite://./db.sqlite3",
    modules={"models": [__name__]},
    generate_schemas=True,
)
```

## 测试分页功能

### 使用 curl

```bash
# 获取第 1 页，每页 10 条
curl "http://localhost:8000/api/v1/users?page=1&page_size=10"

# 获取第 2 页
curl "http://localhost:8000/api/v1/users?page=2&page_size=10"

# 使用大的 page_size（会被限制到 max_page_size）
curl "http://localhost:8000/api/v1/users?page=1&page_size=500"
```

### 使用 .http 文件

创建 `pagination_test.http`:

```http
### 获取用户列表 - 第 1 页
GET http://localhost:8000/api/v1/users?page=1&page_size=10
Content-Type: application/json

###

### 获取用户列表 - 第 2 页
GET http://localhost:8000/api/v1/users?page=2&page_size=10
Content-Type: application/json

###

### 获取用户列表 - 每页 5 条
GET http://localhost:8000/api/v1/users?page=1&page_size=5
Content-Type: application/json

###

### 获取用户列表 - 超大页面（会被限制）
GET http://localhost:8000/api/v1/users?page=1&page_size=1000
Content-Type: application/json
```

### 使用 Python requests

```python
import requests

# 获取第 1 页
response = requests.get(
    "http://localhost:8000/api/v1/users",
    params={"page": 1, "page_size": 10}
)
data = response.json()

print(f"总记录数: {data['count']}")
print(f"当前页: {data['page']}")
print(f"总页数: {data['total_pages']}")
print(f"当前页数据量: {len(data['results'])}")

# 遍历所有页
page = 1
while True:
    response = requests.get(
        "http://localhost:8000/api/v1/users",
        params={"page": page, "page_size": 10}
    )
    data = response.json()
    
    # 处理当前页数据
    for user in data['results']:
        print(f"User: {user['username']}")
    
    # 检查是否有下一页
    if not data['next']:
        break
    
    page += 1
```

## 前端集成示例

### Vue.js 示例

```vue
<template>
  <div>
    <div v-for="user in users" :key="user.id">
      {{ user.username }} - {{ user.email }}
    </div>
    
    <div class="pagination">
      <button @click="prevPage" :disabled="!hasPrev">上一页</button>
      <span>第 {{ currentPage }} / {{ totalPages }} 页</span>
      <button @click="nextPage" :disabled="!hasNext">下一页</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      users: [],
      currentPage: 1,
      totalPages: 1,
      pageSize: 10,
      hasNext: false,
      hasPrev: false,
    }
  },
  mounted() {
    this.loadUsers()
  },
  methods: {
    async loadUsers() {
      const response = await fetch(
        `/api/v1/users?page=${this.currentPage}&page_size=${this.pageSize}`
      )
      const data = await response.json()
      
      this.users = data.results
      this.totalPages = data.total_pages
      this.hasNext = data.next
      this.hasPrev = data.previous
    },
    nextPage() {
      if (this.hasNext) {
        this.currentPage++
        this.loadUsers()
      }
    },
    prevPage() {
      if (this.hasPrev) {
        this.currentPage--
        this.loadUsers()
      }
    }
  }
}
</script>
```

### React 示例

```jsx
import React, { useState, useEffect } from 'react';

function UserList() {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [hasNext, setHasNext] = useState(false);
  const [hasPrev, setHasPrev] = useState(false);
  
  const pageSize = 10;
  
  useEffect(() => {
    loadUsers();
  }, [page]);
  
  const loadUsers = async () => {
    const response = await fetch(
      `/api/v1/users?page=${page}&page_size=${pageSize}`
    );
    const data = await response.json();
    
    setUsers(data.results);
    setTotalPages(data.total_pages);
    setHasNext(data.next);
    setHasPrev(data.previous);
  };
  
  return (
    <div>
      {users.map(user => (
        <div key={user.id}>
          {user.username} - {user.email}
        </div>
      ))}
      
      <div className="pagination">
        <button onClick={() => setPage(page - 1)} disabled={!hasPrev}>
          上一页
        </button>
        <span>第 {page} / {totalPages} 页</span>
        <button onClick={() => setPage(page + 1)} disabled={!hasNext}>
          下一页
        </button>
      </div>
    </div>
  );
}
```

## 高级用法

### 游标分页（Cursor Pagination）

如果需要游标分页（适合实时数据流），可以自定义：

```python
class CursorPagination:
    """游标分页实现"""
    
    def __init__(self, page_size=20):
        self.page_size = page_size
    
    async def paginate_queryset(self, queryset, request, view=None):
        # 获取游标（最后一条记录的 ID）
        cursor = request.query_params.get('cursor')
        page_size = int(request.query_params.get('page_size', self.page_size))
        
        if cursor:
            # 从游标位置开始查询
            queryset = queryset.filter(id__gt=int(cursor))
        
        # 多查询一条以判断是否有下一页
        items = await queryset.limit(page_size + 1).order_by('id')
        
        has_next = len(items) > page_size
        if has_next:
            items = items[:page_size]
        
        self.has_next = has_next
        self.next_cursor = items[-1].id if items and has_next else None
        
        return items
    
    def get_paginated_response(self, data):
        return {
            'next_cursor': self.next_cursor,
            'has_next': self.has_next,
            'results': data
        }
```

### 无限滚动加载

```python
class InfiniteScrollPagination(TortoisePagination):
    """无限滚动分页"""
    
    def __init__(self):
        super().__init__(page_size=20, max_page_size=100)
    
    def get_paginated_response(self, data):
        """简化的响应格式，适合无限滚动"""
        return {
            'has_more': self.page < self.total_pages,
            'next_page': self.page + 1 if self.page < self.total_pages else None,
            'items': data
        }
```

## 常见问题

**Q: 如何设置默认每页数量？**
```python
pagination_class = TortoisePagination(page_size=50)
```

**Q: 如何限制最大页面大小？**
```python
pagination_class = TortoisePagination(max_page_size=100)
```

**Q: 如何禁用分页？**
```python
# 不设置 pagination_class 或设置为 None
pagination_class = None
```

**Q: 如何修改查询参数名称？**
```python
pagination_class = TortoisePagination(
    page_size_query_param='per_page'  # 使用 ?per_page=10
)
```

**Q: 如何在 ViewSet 中使用分页？**
```python
class UserViewSet(ModelViewSet):
    model = User
    serializer_class = UserSerializer
    pagination_class = TortoisePagination  # ViewSet 同样支持
```

**Q: 分页会影响性能吗？**  
A: 分页会执行一次 COUNT 查询获取总数，对于大表可能较慢。可以考虑：
- 使用游标分页避免 COUNT
- 缓存总数（如果不需要精确值）
- 添加数据库索引优化 COUNT 查询

## 总结

分页使用三步走：
1. ✅ 添加 `pagination_class = TortoisePagination`
2. ✅ 访问 API 时添加 `?page=1&page_size=10`
3. ✅ 处理响应中的 `results` 数组

就这么简单！🎉
