"""
DateTime Format Customization Examples

This example demonstrates different ways to customize datetime formatting
in fastapi-cbv serialization.
"""

from fastapi import FastAPI
from tortoise import fields
from tortoise.models import Model

from fastapi_cbv import cbv
from fastapi_cbv.routers import CBVRouter
from fastapi_cbv.views.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from fastapi_cbv.tortoise_integration import create_tortoise_serializer


# Define a simple model
class Event(Model):
    id = fields.IntField(pk=True)
    title = fields.CharField(max_length=200)
    description = fields.TextField()
    event_date = fields.DateField()
    created_at = fields.DatetimeField(auto_now_add=True)
    updated_at = fields.DatetimeField(auto_now=True)

    class Meta:
        table = "events"


# Create serializers
EventSerializer = create_tortoise_serializer(Event, name="EventSerializer")


# Method 1: Use default ISO format (no customization needed)
# Result: "2025-10-04T10:30:45.123456+00:00"
class EventListView(ListCreateAPIView):
    """Events with default ISO datetime format"""
    model = Event
    serializer_class = EventSerializer


# Method 2: Use custom datetime format for all views
# Result: "2025-10-04 10:30:45"
class EventListViewCustomFormat(ListCreateAPIView):
    """Events with custom datetime format: YYYY-MM-DD HH:MM:SS"""
    model = Event
    serializer_class = EventSerializer
    
    # Customize datetime format
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 2025-10-04 10:30:45
    date_format = "%Y-%m-%d"  # 2025-10-04


# Method 3: Different format for detail view
class EventDetailViewShortFormat(RetrieveUpdateDestroyAPIView):
    """Events with short datetime format"""
    model = Event
    serializer_class = EventSerializer
    
    # Use a different format: Chinese style
    datetime_format = "%Y年%m月%d日 %H:%M:%S"  # 2025年10月04日 10:30:45
    date_format = "%Y年%m月%d日"  # 2025年10月04日


# Method 4: Override _model_to_dict for complete control
class EventListViewAdvanced(ListCreateAPIView):
    """Events with advanced datetime formatting logic"""
    model = Event
    serializer_class = EventSerializer
    
    def _model_to_dict(self, instance, serializer_class):
        """
        Override to implement custom datetime formatting logic
        """
        from tortoise import fields as tortoise_fields
        from datetime import datetime, date
        
        data = {}
        model_class = type(instance)
        
        if hasattr(serializer_class, 'model_fields'):
            serializer_fields = serializer_class.model_fields.keys()
        else:
            serializer_fields = model_class._meta.fields_map.keys()
        
        for field_name in serializer_fields:
            if field_name in model_class._meta.fields_map:
                field_obj = model_class._meta.fields_map[field_name]
                
                if isinstance(field_obj, tortoise_fields.relational.ForeignKeyFieldInstance):
                    fk_id_attr = f"{field_name}_id"
                    if hasattr(instance, fk_id_attr):
                        data[field_name] = getattr(instance, fk_id_attr)
                    else:
                        data[field_name] = None
                else:
                    if hasattr(instance, field_name):
                        value = getattr(instance, field_name)
                        
                        # Custom logic: different formats for different fields
                        if isinstance(value, datetime):
                            if field_name == 'created_at':
                                # Full format for created_at
                                value = value.strftime("%Y-%m-%d %H:%M:%S")
                            elif field_name == 'updated_at':
                                # Relative time for updated_at (you could use a library like arrow)
                                value = value.strftime("%Y-%m-%d %H:%M")
                            else:
                                # Default ISO format
                                value = value.isoformat()
                        elif isinstance(value, date):
                            # Custom date format
                            value = value.strftime("%d/%m/%Y")
                        
                        data[field_name] = value
        
        return data


# Setup FastAPI app
app = FastAPI(title="DateTime Format Examples")
router = CBVRouter()

# Register routes with different formats
@cbv(router)
class EventAPIView:
    """Event API endpoints"""
    pass

# Add routes
router.add_api_route(
    "/events/default",
    EventListView.as_view(),
    methods=["GET", "POST"],
    name="events-default"
)

router.add_api_route(
    "/events/custom",
    EventListViewCustomFormat.as_view(),
    methods=["GET", "POST"],
    name="events-custom"
)

router.add_api_route(
    "/events/chinese",
    EventDetailViewShortFormat.as_view(),
    methods=["GET"],
    name="events-chinese"
)

router.add_api_route(
    "/events/advanced",
    EventListViewAdvanced.as_view(),
    methods=["GET"],
    name="events-advanced"
)

app.include_router(router, prefix="/api/v1")


# Common datetime format patterns
"""
常用的 datetime 格式模式：

ISO 8601 格式（默认）:
    None  # 使用 .isoformat()
    结果: "2025-10-04T10:30:45.123456+00:00"

标准格式:
    "%Y-%m-%d %H:%M:%S"
    结果: "2025-10-04 10:30:45"

日期和时间分开:
    datetime_format = "%Y-%m-%d %H:%M:%S"
    date_format = "%Y-%m-%d"
    
中文格式:
    "%Y年%m月%d日 %H:%M:%S"
    结果: "2025年10月04日 10:30:45"
    
美式格式:
    "%m/%d/%Y %I:%M %p"
    结果: "10/04/2025 10:30 AM"
    
欧式格式:
    "%d/%m/%Y %H:%M"
    结果: "04/10/2025 10:30"
    
仅日期:
    date_format = "%Y-%m-%d"  # 2025-10-04
    date_format = "%d/%m/%Y"  # 04/10/2025
    date_format = "%Y年%m月%d日"  # 2025年10月04日
    
仅时间:
    "%H:%M:%S"  # 10:30:45
    "%I:%M %p"  # 10:30 AM

Unix 时间戳:
    如果需要返回时间戳，可以在 _model_to_dict 中:
    if isinstance(value, datetime):
        value = int(value.timestamp())
"""


if __name__ == "__main__":
    import uvicorn
    
    print("🚀 DateTime Format Examples Server")
    print("=" * 50)
    print("Available endpoints:")
    print("  - GET  /api/v1/events/default   (ISO format)")
    print("  - GET  /api/v1/events/custom    (YYYY-MM-DD HH:MM:SS)")
    print("  - GET  /api/v1/events/chinese   (中文格式)")
    print("  - GET  /api/v1/events/advanced  (Advanced custom logic)")
    print("=" * 50)
    
    # Note: You'll need to initialize Tortoise ORM before running
    # This is just a demonstration of the format options
    
    # uvicorn.run(app, host="0.0.0.0", port=8001)
