#!/usr/bin/env python3
"""
Simple API test using curl commands
"""

import subprocess
import time
import json

def run_curl(url, method="GET", data=None, expected_status=200):
    """Run curl command and check response"""
    cmd = ["curl", "-s", "-w", "%{http_code}", "-X", method]
    
    if data:
        cmd.extend(["-H", "Content-Type: application/json", "-d", json.dumps(data)])
    
    cmd.append(f"http://localhost:8000{url}")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        
        # Extract status code (last 3 characters)
        output = result.stdout
        status_code = int(output[-3:])
        response_body = output[:-3]
        
        if status_code == expected_status:
            print(f"✅ {method} {url} - Status: {status_code}")
            if response_body:
                try:
                    # Try to parse as JSON and pretty print
                    json_response = json.loads(response_body)
                    print(f"   Response: {json.dumps(json_response, indent=2)}")
                except json.JSONDecodeError:
                    print(f"   Response: {response_body}")
            return True
        else:
            print(f"❌ {method} {url} - Expected: {expected_status}, Got: {status_code}")
            print(f"   Response: {response_body}")
            return False
    
    except subprocess.TimeoutExpired:
        print(f"❌ {method} {url} - Timeout")
        return False
    except Exception as e:
        print(f"❌ {method} {url} - Error: {e}")
        return False

def main():
    """Test API endpoints"""
    print("🧪 Testing FastAPI CBV API with curl")
    print("=" * 50)
    
    # Wait for server to be ready
    print("Waiting for server to be ready...")
    time.sleep(3)
    
    tests = [
        # Basic endpoints
        ("/", "GET", None, 200),
        ("/health", "GET", None, 200),
        
        # CBV endpoints
        ("/api/v1/hello", "GET", None, 200),
        ("/api/v1/hello", "POST", {"test": "data"}, 200),
        ("/api/v1/users/stats", "GET", None, 200),
        ("/api/v1/users", "GET", None, 200),
        ("/api/v1/posts/", "GET", None, 200),
    ]
    
    passed = 0
    total = len(tests)
    
    for url, method, data, expected_status in tests:
        if run_curl(url, method, data, expected_status):
            passed += 1
        print()
    
    print("=" * 50)
    print(f"🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! FastAPI CBV is working correctly!")
    else:
        print(f"⚠️  {total - passed} tests failed.")

if __name__ == "__main__":
    main()