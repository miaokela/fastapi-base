"""
Basic usage examples for FastAPI CBV
"""

# Example 1: Simple API View
"""
from fastapi import FastAPI
from fastapi_cbv import APIView, cbv, CBVRouter

app = FastAPI()
router = CBVRouter()

@cbv(router)
class HelloView(APIView):
    async def get(self):
        return {"message": "Hello World"}
    
    async def post(self):
        data = await self.request.json()
        return {"received": data}

HelloView.add_api_route("/hello")
app.include_router(router)
"""

# Example 2: Model-based View with Tortoise ORM
"""
from fastapi import FastAPI
from tortoise.models import Model
from tortoise import fields
from fastapi_cbv import (
    ListCreateAPIView, 
    RetrieveUpdateDestroyAPIView,
    create_tortoise_serializer,
    CBVRouter
)

class User(Model):
    id = fields.IntField(pk=True)
    name = fields.CharField(max_length=100)
    email = fields.CharField(max_length=100, unique=True)

UserSerializer = create_tortoise_serializer(User)

class UserListView(ListCreateAPIView):
    queryset = User.all()
    serializer_class = UserSerializer

class UserDetailView(RetrieveUpdateDestroyAPIView):
    queryset = User.all()
    serializer_class = UserSerializer

app = FastAPI()
router = CBVRouter()

router.add_cbv_route("/users", UserListView)
router.add_cbv_route("/users/{id}", UserDetailView)

app.include_router(router)
"""

# Example 3: ViewSet Usage
"""
from fastapi_cbv import ModelViewSet, viewset_routes

class UserViewSet(ModelViewSet):
    queryset = User.all()
    serializer_class = UserSerializer
    filter_backends = [TortoiseFilterBackend]
    search_fields = ['name', 'email']

router = CBVRouter()
viewset_routes(router, UserViewSet, prefix="/users")
app.include_router(router)
"""

# Example 4: Custom Mixins
"""
from fastapi_cbv import GenericAPIView, CreateModelMixin, ListModelMixin

class CustomView(CreateModelMixin, ListModelMixin, GenericAPIView):
    queryset = User.all()
    serializer_class = UserSerializer
    
    async def get(self, **kwargs):
        # Custom list logic
        return await self.list(**kwargs)
    
    async def post(self, **kwargs):
        # Custom create logic
        result = await self.create(**kwargs)
        # Add custom logic here
        return result
"""

print("FastAPI CBV examples - check the comments for usage patterns!")