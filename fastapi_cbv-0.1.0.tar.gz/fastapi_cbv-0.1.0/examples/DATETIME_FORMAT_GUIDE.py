"""
DateTime 格式化配置快速参考

在任何视图类中设置 datetime_format 和 date_format 属性来自定义时间格式
"""

# ==========================================
# 常用格式示例
# ==========================================

# 1. 标准格式：年-月-日 时:分:秒
datetime_format = "%Y-%m-%d %H:%M:%S"
# 结果: 2025-10-04 10:30:45

# 2. 中文格式
datetime_format = "%Y年%m月%d日 %H:%M:%S"
# 结果: 2025年10月04日 10:30:45

# 3. 仅日期
date_format = "%Y-%m-%d"
# 结果: 2025-10-04

# 4. 中文日期
date_format = "%Y年%m月%d日"
# 结果: 2025年10月04日

# 5. 美式格式（12小时制）
datetime_format = "%m/%d/%Y %I:%M:%S %p"
# 结果: 10/04/2025 10:30:45 AM

# 6. 欧式格式
datetime_format = "%d/%m/%Y %H:%M:%S"
# 结果: 04/10/2025 10:30:45

# 7. 紧凑格式（无分隔符）
datetime_format = "%Y%m%d%H%M%S"
# 结果: 20251004103045

# 8. ISO 格式（带 T）
datetime_format = "%Y-%m-%dT%H:%M:%S"
# 结果: 2025-10-04T10:30:45

# 9. 仅时间
datetime_format = "%H:%M:%S"
# 结果: 10:30:45

# 10. 中文全格式
datetime_format = "%Y年%m月%d日 %H时%M分%S秒"
# 结果: 2025年10月04日 10时30分45秒


# ==========================================
# 格式符号说明
# ==========================================
"""
%Y  - 四位年份 (2025)
%y  - 两位年份 (25)
%m  - 月份 (01-12)
%d  - 日期 (01-31)
%H  - 小时 24小时制 (00-23)
%I  - 小时 12小时制 (01-12)
%M  - 分钟 (00-59)
%S  - 秒 (00-59)
%p  - AM/PM
%a  - 星期简写 (Mon, Tue, Wed...)
%A  - 星期全称 (Monday, Tuesday...)
%b  - 月份简写 (Jan, Feb, Mar...)
%B  - 月份全称 (January, February...)
"""


# ==========================================
# 实际使用示例
# ==========================================

from fastapi_cbv import ListCreateAPIView

# 示例 1: 标准中国格式
class UserListView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    # 设置为标准的年月日时分秒格式
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 2025-10-04 10:30:45
    date_format = "%Y-%m-%d"                # 2025-10-04


# 示例 2: 中文格式
class PostListView(ListCreateAPIView):
    model = Post
    serializer_class = PostSerializer
    
    # 设置为中文格式
    datetime_format = "%Y年%m月%d日 %H:%M:%S"  # 2025年10月04日 10:30:45
    date_format = "%Y年%m月%d日"              # 2025年10月04日


# 示例 3: 短格式（不含秒）
class EventListView(ListCreateAPIView):
    model = Event
    serializer_class = EventSerializer
    
    # 简化格式，不显示秒
    datetime_format = "%Y-%m-%d %H:%M"  # 2025-10-04 10:30
    date_format = "%Y-%m-%d"            # 2025-10-04


# 示例 4: 不同视图使用不同格式
class DetailView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    # 详情页使用完整格式
    datetime_format = "%Y年%m月%d日 %H时%M分%S秒"


class ListView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    # 列表页使用简洁格式
    datetime_format = "%Y-%m-%d %H:%M"


# ==========================================
# 高级用法：自定义不同字段的格式
# ==========================================

class AdvancedView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    def _model_to_dict(self, instance, serializer_class):
        """
        重写此方法可以对不同字段使用不同的格式
        """
        from tortoise import fields as tortoise_fields
        from datetime import datetime, date
        
        data = {}
        model_class = type(instance)
        
        if hasattr(serializer_class, 'model_fields'):
            serializer_fields = serializer_class.model_fields.keys()
        else:
            serializer_fields = model_class._meta.fields_map.keys()
        
        for field_name in serializer_fields:
            if field_name in model_class._meta.fields_map:
                field_obj = model_class._meta.fields_map[field_name]
                
                if isinstance(field_obj, tortoise_fields.relational.ForeignKeyFieldInstance):
                    fk_id_attr = f"{field_name}_id"
                    if hasattr(instance, fk_id_attr):
                        data[field_name] = getattr(instance, fk_id_attr)
                    else:
                        data[field_name] = None
                else:
                    if hasattr(instance, field_name):
                        value = getattr(instance, field_name)
                        
                        if isinstance(value, datetime):
                            # 根据字段名使用不同格式
                            if field_name == 'created_at':
                                # 创建时间使用完整格式
                                value = value.strftime("%Y-%m-%d %H:%M:%S")
                            elif field_name == 'updated_at':
                                # 更新时间使用简短格式
                                value = value.strftime("%Y-%m-%d %H:%M")
                            elif field_name == 'birthday':
                                # 生日只显示日期
                                value = value.strftime("%Y-%m-%d")
                            else:
                                # 其他字段使用默认格式
                                value = value.isoformat()
                        elif isinstance(value, date):
                            value = value.strftime("%Y-%m-%d")
                        
                        data[field_name] = value
        
        return data


# ==========================================
# 返回 Unix 时间戳
# ==========================================

class TimestampView(ListCreateAPIView):
    model = User
    serializer_class = UserSerializer
    
    def _model_to_dict(self, instance, serializer_class):
        """返回 Unix 时间戳（秒）"""
        from tortoise import fields as tortoise_fields
        from datetime import datetime, date
        
        data = {}
        model_class = type(instance)
        
        if hasattr(serializer_class, 'model_fields'):
            serializer_fields = serializer_class.model_fields.keys()
        else:
            serializer_fields = model_class._meta.fields_map.keys()
        
        for field_name in serializer_fields:
            if field_name in model_class._meta.fields_map:
                field_obj = model_class._meta.fields_map[field_name]
                
                if isinstance(field_obj, tortoise_fields.relational.ForeignKeyFieldInstance):
                    fk_id_attr = f"{field_name}_id"
                    if hasattr(instance, fk_id_attr):
                        data[field_name] = getattr(instance, fk_id_attr)
                    else:
                        data[field_name] = None
                else:
                    if hasattr(instance, field_name):
                        value = getattr(instance, field_name)
                        
                        if isinstance(value, datetime):
                            # 转换为 Unix 时间戳（秒）
                            value = int(value.timestamp())
                        elif isinstance(value, date):
                            # date 转换为 datetime 再转时间戳
                            from datetime import datetime as dt
                            value = int(dt.combine(value, dt.min.time()).timestamp())
                        
                        data[field_name] = value
        
        return data


# ==========================================
# 常见问题 FAQ
# ==========================================
"""
Q1: 如果不设置 datetime_format，会使用什么格式？
A1: 默认使用 ISO 8601 格式：2025-10-04T10:30:45.123456+00:00

Q2: 可以只设置部分视图的格式吗？
A2: 可以！每个视图类都可以有自己的 datetime_format 配置

Q3: datetime_format 和 date_format 有什么区别？
A3: datetime_format 用于 DatetimeField，date_format 用于 DateField

Q4: 如何在不同环境使用不同格式？
A4: 可以通过环境变量或配置文件来动态设置：
    import os
    datetime_format = os.getenv("DATETIME_FORMAT", "%Y-%m-%d %H:%M:%S")

Q5: 可以返回毫秒吗？
A5: 可以使用 %f 来显示微秒（6位）：
    datetime_format = "%Y-%m-%d %H:%M:%S.%f"  # 2025-10-04 10:30:45.123456
    
    如果只要毫秒（3位），需要自定义：
    value = value.strftime("%Y-%m-%d %H:%M:%S") + f".{value.microsecond // 1000:03d}"

Q6: 如何处理时区？
A6: 可以在格式中包含时区信息：
    datetime_format = "%Y-%m-%d %H:%M:%S %z"  # 包含 UTC 偏移
    datetime_format = "%Y-%m-%d %H:%M:%S %Z"  # 包含时区名称
"""
