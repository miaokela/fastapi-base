# FastAPI-CBV 默认配置说明

## 📋 默认配置项

FastAPI-CBV 已经为常用配置设置了默认值，无需在每个视图类中重复定义。

### 1. lookup_field（查找字段）

**默认值：** `"id"`

**说明：** 用于详情、更新、删除操作时查找对象的字段名。

**示例：**
```python
# 无需再定义 lookup_field，默认使用 "id"
class UserDetailView(RetrieveUpdateDestroyAPIView):
    serializer_class = UserSerializer
    # lookup_field = "id"  # 不再需要！
    
    def get_queryset(self):
        return User.all()
```

**URL 使用：**
```python
# 路由定义
router.add_cbv_route("/users/{id}", UserDetailView)

# 请求示例
GET /api/users/1      # 自动使用 id 字段查找
GET /api/users/123    # 自动使用 id 字段查找
```

**自定义覆盖：**
```python
# 如果需要使用其他字段（如 username），可以覆盖
class UserDetailView(RetrieveUpdateDestroyAPIView):
    lookup_field = "username"  # 覆盖默认值
    # ...

# URL: /users/{username}
# 请求: GET /api/users/john_doe
```

---

### 2. datetime_format（日期时间格式）

**默认值：** `"%Y-%m-%d %H:%M:%S"`

**说明：** DateTime 对象的序列化格式（年-月-日 时:分:秒）。

**格式示例：** `"2025-10-04 15:30:45"`

**示例：**
```python
# 无需再定义 datetime_format
class UserListView(ListCreateAPIView):
    serializer_class = UserSerializer
    # datetime_format = "%Y-%m-%d %H:%M:%S"  # 不再需要！
    
    def get_queryset(self):
        return User.all()
```

**API 响应：**
```json
{
    "id": 1,
    "username": "john_doe",
    "created_at": "2025-10-04 15:30:45",  // 自动格式化
    "updated_at": "2025-10-04 16:20:30"   // 自动格式化
}
```

**自定义覆盖：**
```python
# 使用其他格式
class UserListView(ListCreateAPIView):
    datetime_format = "%d/%m/%Y %H:%M"  # 欧洲格式: 04/10/2025 15:30
    # datetime_format = "%Y年%m月%d日 %H:%M:%S"  # 中文格式
    # datetime_format = None  # ISO 格式: 2025-10-04T15:30:45
```

---

### 3. date_format（日期格式）

**默认值：** `"%Y-%m-%d"`

**说明：** Date 对象的序列化格式（年-月-日）。

**格式示例：** `"2025-10-04"`

**示例：**
```python
# 无需再定义 date_format
class EventListView(ListCreateAPIView):
    serializer_class = EventSerializer
    # date_format = "%Y-%m-%d"  # 不再需要！
```

**API 响应：**
```json
{
    "id": 1,
    "event_name": "Product Launch",
    "event_date": "2025-10-15"  // 自动格式化
}
```

**自定义覆盖：**
```python
# 使用其他格式
class EventListView(ListCreateAPIView):
    date_format = "%d/%m/%Y"  # 15/10/2025
    # date_format = "%Y年%m月%d日"  # 2025年10月15日
    # date_format = None  # ISO 格式: 2025-10-15
```

---

## 🎯 使用场景对比

### ❌ 之前（需要重复定义）

```python
class UserListView(ListCreateAPIView):
    serializer_class = UserSerializer
    lookup_field = "id"  # 每个类都要写
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 每个类都要写
    date_format = "%Y-%m-%d"  # 每个类都要写
    
    def get_queryset(self):
        return User.all()

class UserDetailView(RetrieveUpdateDestroyAPIView):
    serializer_class = UserSerializer
    lookup_field = "id"  # 重复！
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 重复！
    date_format = "%Y-%m-%d"  # 重复！
    
    def get_queryset(self):
        return User.all()

class PostViewSet(ModelViewSet):
    serializer_class = PostSerializer
    lookup_field = "id"  # 重复！
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 重复！
    date_format = "%Y-%m-%d"  # 重复！
    
    def get_queryset(self):
        return Post.all()
```

### ✅ 现在（简洁清晰）

```python
class UserListView(ListCreateAPIView):
    serializer_class = UserSerializer
    
    def get_queryset(self):
        return User.all()

class UserDetailView(RetrieveUpdateDestroyAPIView):
    serializer_class = UserSerializer
    
    def get_queryset(self):
        return User.all()

class PostViewSet(ModelViewSet):
    serializer_class = PostSerializer
    
    def get_queryset(self):
        return Post.all()
```

---

## 🔧 全局配置与局部覆盖

### 方法 1: 使用默认配置（推荐）

大多数情况下，直接使用默认配置即可：

```python
class MyView(ListCreateAPIView):
    serializer_class = MySerializer
    # 自动使用默认配置
```

### 方法 2: 局部覆盖

仅在特定视图需要不同配置时覆盖：

```python
class SpecialView(ListCreateAPIView):
    serializer_class = MySerializer
    lookup_field = "slug"  # 覆盖默认的 "id"
    datetime_format = "%d/%m/%Y %H:%M"  # 覆盖默认格式
```

### 方法 3: 基类统一配置

如果项目有特定需求，可以创建自定义基类：

```python
from fastapi_cbv.views import ListCreateAPIView

class MyProjectBaseView(ListCreateAPIView):
    """项目统一基类"""
    datetime_format = "%Y年%m月%d日 %H:%M:%S"  # 中文格式
    date_format = "%Y年%m月%d日"

# 继承自定义基类
class UserListView(MyProjectBaseView):
    serializer_class = UserSerializer
    # 自动使用基类配置
```

---

## 📝 配置优先级

配置的应用优先级从高到低：

1. **实例级别** - 类中显式定义的属性
2. **默认配置** - GenericAPIView 的默认值
3. **None** - 未配置时的回退值

**示例：**
```python
class MyView(ListCreateAPIView):
    # 优先级 1: 显式定义（最高优先级）
    datetime_format = "%d/%m/%Y"
    
    # 优先级 2: 如果不定义，使用默认值 "%Y-%m-%d %H:%M:%S"
    # date_format 未定义，使用默认值 "%Y-%m-%d"
```

---

## 🌍 国际化支持

根据不同地区需求自定义格式：

```python
# 中国大陆（默认）
datetime_format = "%Y-%m-%d %H:%M:%S"  # 2025-10-04 15:30:45
date_format = "%Y-%m-%d"                # 2025-10-04

# 美国
datetime_format = "%m/%d/%Y %I:%M %p"   # 10/04/2025 03:30 PM
date_format = "%m/%d/%Y"                 # 10/04/2025

# 欧洲
datetime_format = "%d/%m/%Y %H:%M"      # 04/10/2025 15:30
date_format = "%d/%m/%Y"                 # 04/10/2025

# 日本
datetime_format = "%Y年%m月%d日 %H:%M:%S"  # 2025年10月04日 15:30:45
date_format = "%Y年%m月%d日"               # 2025年10月04日
```

---

## ⚙️ 完整配置参考

```python
from fastapi_cbv.views import ModelViewSet
from fastapi_cbv.tortoise_integration import TortoisePagination

class MyViewSet(ModelViewSet):
    # === 必需配置 ===
    serializer_class = MySerializer  # 序列化器类
    
    # === 可选配置（有默认值）===
    lookup_field = "id"  # 默认："id"
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 默认：年-月-日 时:分:秒
    date_format = "%Y-%m-%d"  # 默认：年-月-日
    
    # === 其他可选配置 ===
    pagination_class = TortoisePagination  # 分页类
    filter_backends = []  # 过滤后端
    search_fields = []    # 搜索字段
    ordering_fields = []  # 排序字段
    ordering = None       # 默认排序
    
    def get_queryset(self):
        return MyModel.all()
```

---

## 💡 最佳实践

1. **保持简洁** - 只覆盖需要修改的配置
2. **统一风格** - 项目内使用一致的日期时间格式
3. **文档说明** - 在 API 文档中注明日期格式
4. **前端配合** - 前端应能正确解析配置的格式

```python
# ✅ 好的做法：简洁明了
class UserListView(ListCreateAPIView):
    serializer_class = UserSerializer
    pagination_class = TortoisePagination

# ❌ 避免：不必要的重复
class UserListView(ListCreateAPIView):
    serializer_class = UserSerializer
    pagination_class = TortoisePagination
    lookup_field = "id"  # 不需要，已经是默认值
    datetime_format = "%Y-%m-%d %H:%M:%S"  # 不需要，已经是默认值
    date_format = "%Y-%m-%d"  # 不需要，已经是默认值
```

---

## 🔍 调试提示

如果需要查看当前使用的配置：

```python
class MyView(ListCreateAPIView):
    serializer_class = MySerializer
    
    async def list(self, **kwargs):
        print(f"lookup_field: {self.lookup_field}")
        print(f"datetime_format: {self.datetime_format}")
        print(f"date_format: {self.date_format}")
        return await super().list(**kwargs)
```

---

## 总结

✅ **默认配置已设置：**
- `lookup_field = "id"` - 使用 ID 字段查找对象
- `datetime_format = "%Y-%m-%d %H:%M:%S"` - 年-月-日 时:分:秒 格式
- `date_format = "%Y-%m-%d"` - 年-月-日 格式

✅ **优势：**
- 代码更简洁
- 减少重复
- 统一项目规范
- 易于维护

✅ **灵活性：**
- 随时可以覆盖默认值
- 支持视图级别自定义
- 支持基类级别统一配置
